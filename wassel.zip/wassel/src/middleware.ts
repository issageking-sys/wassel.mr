import { NextResponse, type NextRequest } from "next/server";
// Cheap edge pre-check only (cookie present). REAL enforcement is in pages/actions via lib/auth.
export function middleware(req: NextRequest) {
  if (!req.cookies.get("wassel_session")) {
    const url = new URL("/login", req.url);
    url.searchParams.set("next", req.nextUrl.pathname);
    return NextResponse.redirect(url);
  }
}
export const config = { matcher: ["/owner/:path*", "/staff/:path*", "/seller/:path*", "/agent/:path*", "/account/:path*", "/security/:path*", "/change-password/:path*"] };
