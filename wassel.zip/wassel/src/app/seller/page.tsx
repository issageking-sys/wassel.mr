import { requirePermission } from "@/lib/auth";
import { logoutAction } from "../login/actions";
export default async function Page() {
  const a = await requirePermission("seller.portal");
  return (<main className="mx-auto max-w-2xl p-6"><h1 className="text-2xl font-bold">لوحة البائع</h1>
    <p className="mt-2">مرحبًا {a.name} — الصلاحية تعمل. المحتوى الفعلي في المرحلة 4.</p>
    <form action={logoutAction} className="mt-6"><button className="underline">تسجيل الخروج</button></form></main>);
}
