"use client";
import { useActionState, useState } from "react";
import { loginAction, type LoginState } from "./actions";
export default function LoginForm({ next }: { next?: string }) {
  const [s, action, pending] = useActionState<LoginState, FormData>(loginAction, {});
  const [phone, setPhone] = useState(""), [password, setPassword] = useState("");
  const i = "w-full rounded-xl border border-brand-100 bg-white px-4 py-3 text-base outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20";
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <div><label htmlFor="phone" className="mb-1 block text-sm font-medium">رقم الهاتف</label>
        <input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="username" dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+222 XX XX XX XX" className={`${i} text-start`} required /></div>
      <div><label htmlFor="password" className="mb-1 block text-sm font-medium">كلمة المرور</label>
        <input id="password" name="password" type="password" autoComplete="current-password" dir="ltr" value={password} onChange={(e) => setPassword(e.target.value)} className={`${i} text-start`} required /></div>
      {s.needsCode && <div><label htmlFor="code" className="mb-1 block text-sm font-medium">رمز التحقق (6 أرقام) أو رمز استرداد</label>
        <input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" dir="ltr" autoFocus className={`${i} text-start`} /></div>}
      {s.error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{s.error}</p>}
      <button disabled={pending} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white transition hover:bg-brand-900 disabled:opacity-60">{pending ? "جارٍ الدخول…" : s.needsCode ? "تأكيد" : "تسجيل الدخول"}</button>
    </form>);
}
