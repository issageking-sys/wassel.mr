"use server";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { createSession, destroySession } from "@/lib/session";
import { normalizePhone, verifyPassword, hashPassword } from "@/lib/password";
import { roleHome } from "@/lib/rbac";
import { decrypt, hashCode, verifyTotp } from "@/lib/totp";

export type LoginState = { error?: string; needsCode?: boolean };
const schema = z.object({ phone: z.string().min(6).max(20), password: z.string().min(1).max(128) });
const MAX_FAILS = 5, LOCK_MS = 15 * 60 * 1000;
const GENERIC = "رقم الهاتف أو كلمة المرور غير صحيحة";
let dummy: Promise<string> | undefined;

async function fail(id: string, current: number, ip?: string) {
  const fails = current + 1;
  await db.user.update({ where: { id }, data: { failedLogins: fails, lockedUntil: fails >= MAX_FAILS ? new Date(Date.now() + LOCK_MS) : null } });
  await audit({ actorId: id, action: "auth.login.failed", entityType: "User", entityId: id, ip });
}
async function secondFactorOk(u: { id: string; totpSecretEnc: string | null }, code: string) {
  if (/^\d{6}$/.test(code) && u.totpSecretEnc) return verifyTotp(decrypt(u.totpSecretEnc), code);
  const r = await db.recoveryCode.updateMany({ where: { userId: u.id, codeHash: hashCode(code), usedAt: null }, data: { usedAt: new Date() } });
  if (r.count === 1) await audit({ actorId: u.id, action: "auth.recovery_code.used", entityType: "User", entityId: u.id });
  return r.count === 1;
}

export async function loginAction(_: LoginState, fd: FormData): Promise<LoginState> {
  const parsed = schema.safeParse({ phone: fd.get("phone"), password: fd.get("password") });
  const phone = parsed.success ? normalizePhone(parsed.data.phone) : null;
  if (!parsed.success || !phone) return { error: GENERIC };
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim();
  const user = await db.user.findUnique({ where: { phone }, include: { roles: { include: { role: true } } } });
  if (user?.lockedUntil && user.lockedUntil > new Date()) return { error: "الحساب مقفل مؤقتًا. حاول لاحقًا." };
  const ok = await verifyPassword(parsed.data.password, user?.passwordHash ?? (await (dummy ??= hashPassword("x"))));
  if (!user || !ok || user.status !== "ACTIVE") { if (user) await fail(user.id, user.failedLogins, ip); return { error: GENERIC }; }

  if (user.totpEnabled) {
    const code = String(fd.get("code") ?? "").replace(/\s/g, "");
    if (!code) return { needsCode: true };
    if (!(await secondFactorOk(user, code))) { await fail(user.id, user.failedLogins, ip); return { needsCode: true, error: "رمز التحقق غير صحيح" }; }
  }
  await db.user.update({ where: { id: user.id }, data: { failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() } });
  await createSession(user.id, { ip, userAgent: h.get("user-agent") ?? undefined });
  await audit({ actorId: user.id, action: "auth.login", entityType: "User", entityId: user.id, ip });
  if (user.mustChangePassword) redirect("/change-password");
  const next = String(fd.get("next") ?? "");
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : roleHome(user.roles.map((r) => r.role.key)));
}
export async function logoutAction() { await destroySession(); redirect("/login"); }
