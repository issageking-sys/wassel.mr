import LoginForm from "./LoginForm";
export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return (
    <main className="grid min-h-dvh place-items-center p-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-sm ring-1 ring-brand-100">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-brand-700">وصّل</h1>
          <p className="text-sm text-gold-500">من البائع إلى بابك.</p>
        </div>
        <LoginForm next={next} />
      </div>
    </main>
  );
}
