import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getSettings } from "@/lib/site";
import { savePage } from "../ops/actions";
export default async function Pages() {
  await requirePermission("settings.manage");
  const s = await getSettings();
  return (<main className="mx-auto max-w-2xl space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">الصفحات</h1>
    {([["page_about", "من نحن"], ["page_terms", "الشروط والأحكام"], ["page_privacy", "سياسة الخصوصية"]] as const).map(([k, t]) => (
      <form key={k} action={savePage} className="space-y-2 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><input type="hidden" name="key" value={k} /><h2 className="font-bold">{t}</h2>
        <textarea name="body" rows={7} defaultValue={s[k] ?? ""} className="w-full rounded-lg border border-brand-100 px-3 py-2 text-sm" /><button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">حفظ</button></form>))}
    <p className="text-xs">اكتب النصوص بنفسك؛ لا توجد نصوص قانونية جاهزة.</p></main>);
}
