import Link from "next/link";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";
import { saveProfile } from "../ops/actions";
export default async function Profile() {
  const a = await requireAuth();
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  const i = "w-full rounded-lg border border-brand-100 px-3 py-2";
  return (<main className="mx-auto max-w-md space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">الملف الشخصي</h1>
    <form action={saveProfile} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><label className="block text-sm">الاسم<input name="name" defaultValue={u.name} className={i} required /></label>
      <label className="block text-sm">البريد الإلكتروني (اختياري)<input name="email" type="email" dir="ltr" defaultValue={u.email ?? ""} className={i} /></label>
      <p className="text-sm">الهاتف: <b dir="ltr">{u.phone}</b> <span className="text-xs opacity-60">(تغييره يتطلب إعادة تحقق)</span></p>
      <button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">حفظ</button></form></main>);
}
