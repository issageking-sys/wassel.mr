import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { getSettings, numSetting } from "@/lib/site";
import { addCity, addZone, saveCompany, toggleCity } from "../actions";

export default async function Settings() {
  await requirePermission("settings.manage");
  const [site, cities] = await Promise.all([getSettings(), db.city.findMany({ orderBy: { sortOrder: "asc" }, include: { zones: true } })]);
  const i = "w-full rounded-lg border border-brand-100 bg-white px-3 py-2 text-sm";
  const Card = ({ t, children }: { t: string; children: React.ReactNode }) => <section className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><h2 className="font-bold">{t}</h2>{children}</section>;
  return (
    <main className="mx-auto max-w-2xl space-y-4 p-4 md:p-8">
      <Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link>
      <h1 className="text-2xl font-bold">معلومات الشركة والتوصيل والمدن</h1>
      <Card t="معلومات الشركة">
        <form action={saveCompany} className="space-y-2">
          <input name="company_name" defaultValue={site.company_name ?? ""} placeholder="اسم الشركة" className={i} />
          <input name="phone" dir="ltr" defaultValue={site.phone ?? ""} placeholder="هاتف التواصل" className={`${i} text-start`} />
          <input name="whatsapp" dir="ltr" defaultValue={site.whatsapp ?? ""} placeholder="واتساب بالصيغة الدولية: 222XXXXXXXX" className={`${i} text-start`} />
          <input name="email" dir="ltr" defaultValue={site.email ?? ""} placeholder="البريد الإلكتروني" className={`${i} text-start`} />
          <label className="block text-xs">رسوم التوصيل داخل نفس المدينة (أوقية)<input name="fee_same" type="number" min={0} defaultValue={numSetting(site.fee_same, 50)} className={i} /></label>
          <label className="block text-xs">رسوم التوصيل بين مدينتين (أوقية)<input name="fee_cross" type="number" min={0} defaultValue={numSetting(site.fee_cross, 100)} className={i} /></label>
          <label className="block text-xs">رسوم تغليف الهدية (0 = غير متاح)<input name="gift_fee" type="number" min={0} defaultValue={numSetting(site.gift_fee, 0)} className={i} /></label>
          <button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">حفظ</button></form>
        <p className="text-xs">رقم واتساب يظهر في تذييل الموقع وفي صفحة "كن بائعًا معنا".</p>
      </Card>
      <Card t="المدن والمناطق">
        {cities.map((c) => (
          <div key={c.id} className="space-y-1 border-b border-brand-100 pb-2">
            <div className="flex items-center justify-between"><b>{c.nameAr} <span className="text-xs font-normal" dir="ltr">({c.slug})</span></b>
              <form action={toggleCity}><input type="hidden" name="id" value={c.id} /><button className="text-xs underline">{c.isActive ? "نشطة — إيقاف" : "متوقفة — تفعيل"}</button></form></div>
            <p className="text-xs">المناطق: {c.zones.length ? c.zones.map((z) => z.nameAr).join("، ") : "لا توجد بعد"}</p>
            <form action={addZone} className="flex gap-2"><input type="hidden" name="cityId" value={c.id} /><input name="nameAr" placeholder="منطقة جديدة" className={i} required /><button className="rounded-lg bg-brand-700 px-3 text-sm text-white">إضافة</button></form>
          </div>))}
        <form action={addCity} className="flex flex-wrap gap-2"><input name="nameAr" placeholder="اسم المدينة بالعربية" className={`${i} flex-1`} required /><input name="slug" dir="ltr" placeholder="slug: rosso" pattern="[a-z0-9\-]{2,40}" className={`${i} w-32`} required /><button className="rounded-lg bg-brand-700 px-3 text-sm text-white">إضافة مدينة</button></form>
      </Card>
      <p className="text-xs">قريبًا: رسوم التوصيل، العمولة، طرق الدفع، الأمان، صفحات الموقع.</p>
    </main>);
}
