"use server";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { assertPermission } from "@/lib/auth";
const ip = async () => (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim();

export async function saveCompany(fd: FormData) {
  const a = await assertPermission("settings.manage");
  const p = z.object({ company_name: z.string().trim().max(80), phone: z.string().trim().max(30), whatsapp: z.string().trim().max(30), email: z.string().trim().max(120), fee_same: z.string().regex(/^\d{0,7}$/), fee_cross: z.string().regex(/^\d{0,7}$/), gift_fee: z.string().regex(/^\d{0,7}$/) }).parse(Object.fromEntries(fd));
  const old = Object.fromEntries((await db.siteSetting.findMany()).map((r) => [r.key, r.value]));
  for (const [key, value] of Object.entries(p)) await db.siteSetting.upsert({ where: { key }, update: { value }, create: { key, value } });
  await audit({ actorId: a.userId, action: "settings.company.update", entityType: "SiteSetting", oldValue: old, newValue: p, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function addCity(fd: FormData) {
  const a = await assertPermission("settings.manage");
  const p = z.object({ nameAr: z.string().trim().min(2).max(60), slug: z.string().regex(/^[a-z0-9-]{2,40}$/) }).parse(Object.fromEntries(fd));
  const c = await db.city.create({ data: { ...p, isActive: true, sortOrder: (await db.city.count()) + 1 } });
  await audit({ actorId: a.userId, action: "city.create", entityType: "City", entityId: c.id, newValue: p, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function toggleCity(fd: FormData) {
  const a = await assertPermission("settings.manage");
  const id = z.string().parse(fd.get("id"));
  const c = await db.city.findUniqueOrThrow({ where: { id } });
  await db.city.update({ where: { id }, data: { isActive: !c.isActive } });
  await audit({ actorId: a.userId, action: "city.toggle", entityType: "City", entityId: id, oldValue: { isActive: c.isActive }, newValue: { isActive: !c.isActive }, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function addZone(fd: FormData) {
  const a = await assertPermission("settings.manage");
  const p = z.object({ cityId: z.string(), nameAr: z.string().trim().min(2).max(60) }).parse(Object.fromEntries(fd));
  const zn = await db.zone.create({ data: p });
  await audit({ actorId: a.userId, action: "zone.create", entityType: "Zone", entityId: zn.id, newValue: p, ip: await ip() });
  revalidatePath("/owner/settings");
}
