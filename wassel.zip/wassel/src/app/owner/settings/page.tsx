import Link from "next/link";
import { requireAuth } from "@/lib/auth";
const ITEMS: [string, string, string?][] = [["/owner/orders", "الطلبات", "orders.manage"], ["/owner/products", "المنتجات", "catalog.manage"], ["/owner/sections", "الأقسام", "catalog.manage"], ["/owner/workers", "العمال", "users.manage"], ["/owner/applications", "طلبات الانضمام", "users.manage"], ["/owner/tickets", "الدعم الفني (التذاكر)", "support.manage"], ["/owner/pages", "الصفحات: من نحن · الشروط · الخصوصية", "settings.manage"], ["/owner/settings/company", "معلومات الشركة والتوصيل والمدن", "settings.manage"], ["/owner/notifications", "الإشعارات", "dashboard.view"], ["/owner/profile", "الملف الشخصي"], ["/owner/appearance", "المظهر والوضع الليلي"], ["/security", "الأمان وكلمة المرور"]];
export default async function Hub() {
  const a = await requireAuth();
  return (<main className="mx-auto max-w-2xl space-y-3 p-4 md:p-8"><Link href="/owner" className="text-sm underline">← مركز القيادة</Link><h1 className="text-2xl font-bold">الإعدادات</h1>
    <div className="grid gap-3 md:grid-cols-2">{ITEMS.filter(([, , p]) => !p || a.permissions.has(p)).map(([h, t]) => <Link key={h} href={h} className="rounded-2xl bg-white p-4 font-bold ring-1 ring-brand-100 hover:shadow-md">{t}</Link>)}</div></main>);
}
