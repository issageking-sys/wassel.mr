import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import ImageInput from "@/components/ImageInput";
import { addSection, toggleSection } from "../catalog/actions";
export default async function Sections() {
  await requirePermission("catalog.manage");
  const list = await db.category.findMany({ where: { parentId: null }, orderBy: { sortOrder: "asc" }, include: { _count: { select: { products: true } } } });
  return (<main className="mx-auto max-w-2xl space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">إدارة الأقسام</h1>
    <form action={addSection} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><h2 className="font-bold">قسم جديد</h2>
      <label className="block text-sm">صورة القسم<ImageInput maxWidth={900} /></label>
      <input name="name" placeholder="اسم القسم" className="w-full rounded-lg border border-brand-100 px-3 py-2" required />
      <button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">إضافة القسم</button></form>
    <section className="space-y-2">{list.length === 0 && <p className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100">لا توجد أقسام.</p>}
      {list.map((c) => <div key={c.id} className="flex items-center justify-between rounded-2xl bg-white p-3 ring-1 ring-brand-100"><span><b>{c.nameAr}</b> {!c.isActive && <span className="text-xs">(مخفي)</span>}<br /><small>{c._count.products} منتج</small></span>
        <form action={toggleSection}><input type="hidden" name="id" value={c.id} /><button className="text-sm underline">{c.isActive ? "إخفاء" : "إظهار"}</button></form></div>)}</section></main>);
}
