import Link from "next/link";
import { requireRole } from "@/lib/auth";
import { db } from "@/lib/db";
import { logoutAction } from "../login/actions";

function Card({ t, v, soon }: { t: string; v?: number; soon?: string }) {
  return (
    <div className="rounded-2xl bg-white p-4 ring-1 ring-brand-100">
      <p className="text-sm text-brand-700/70">{t}</p>
      <p className="mt-1 text-2xl font-bold">{soon ? <span className="text-base font-medium text-gold-500">{soon}</span> : v}</p>
    </div>
  );
}

export default async function OwnerDashboard() {
  const a = await requireRole("OWNER");
  const [cities, users, byRole, audits, pendingApps] = await Promise.all([
    db.city.count({ where: { isActive: true } }),
    db.user.count({ where: { status: "ACTIVE" } }),
    db.role.findMany({ select: { nameAr: true, key: true, _count: { select: { users: true } } } }),
    db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 8, include: { actor: { select: { name: true } } } }),
    db.sellerApplication.count({ where: { status: "PENDING" } }),
  ]);
  return (
    <main className="mx-auto max-w-4xl space-y-6 p-4 md:p-8">
      <header className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">مركز القيادة</h1><p className="text-sm">المالك: {a.name}</p></div>
        <form action={logoutAction}><button className="text-sm underline">خروج</button></form>
      </header>
      {!a.totpEnabled && <p className="rounded-xl bg-gold-400/20 p-3 text-sm">المصادقة الثنائية غير مفعّلة بعد. العمليات الحساسة على حسابات المالك مقفلة حتى تفعيلها. <Link href="/security" className="underline">فعّلها الآن</Link></p>}
      <nav className="flex flex-wrap gap-2">{[["/owner/orders", "الطلبات"], ["/owner/products", "المنتجات"], ["/owner/sections", "الأقسام"], ["/owner/workers", "العمال"], ["/owner/applications", pendingApps ? `طلبات الانضمام (${pendingApps} جديد)` : "طلبات الانضمام"], ["/owner/settings", "الإعدادات"], ["/security", "الأمان"]].map(([h, t]) => <Link key={h} href={h} className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-bold text-white">{t}</Link>)}</nav>
      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card t="المدن النشطة" v={cities} /><Card t="المستخدمون النشطون" v={users} />
        <Card t="طلبات اليوم" soon="المرحلة 3" /><Card t="صافي الربح" soon="المرحلة 7" />
      </section>
      <section><h2 className="mb-2 font-bold">المستخدمون حسب الدور</h2>
        <div className="flex flex-wrap gap-2">{byRole.map((r) => <span key={r.key} className="rounded-full bg-white px-3 py-1 text-sm ring-1 ring-brand-100">{r.nameAr}: {r._count.users}</span>)}</div></section>
      <section><h2 className="mb-2 font-bold">آخر العمليات (Audit Log)</h2>
        <ul className="divide-y divide-brand-100 rounded-2xl bg-white ring-1 ring-brand-100">
          {audits.map((l) => <li key={l.id} className="flex justify-between gap-2 p-3 text-sm"><span dir="ltr">{l.action}</span><span>{l.actor?.name ?? "—"} · {l.createdAt.toLocaleString("ar")}</span></li>)}
        </ul></section>
    </main>
  );
}
