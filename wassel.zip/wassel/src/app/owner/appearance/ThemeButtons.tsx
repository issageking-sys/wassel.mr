"use client";
export default function ThemeButtons() {
  function set(t: string) { try { localStorage.setItem("wtheme", t); } catch {} if (t === "auto") document.documentElement.removeAttribute("data-theme"); else document.documentElement.setAttribute("data-theme", t); }
  return <div className="flex flex-wrap gap-2">{[["auto", "تلقائي"], ["light", "نهاري"], ["dark", "ليلي"]].map(([k, t]) => <button key={k} onClick={() => set(k)} className="rounded-xl bg-brand-700 px-5 py-2 font-bold text-white">{t}</button>)}</div>;
}
