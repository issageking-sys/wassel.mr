import Link from "next/link";
import ThemeButtons from "./ThemeButtons";
export default function Appearance() {
  return (<main className="mx-auto max-w-md space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">المظهر</h1>
    <div className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><p>اختر مظهر الموقع على هذا الجهاز:</p><ThemeButtons /></div></main>);
}
