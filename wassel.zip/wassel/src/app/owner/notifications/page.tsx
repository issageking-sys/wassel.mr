import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/site";
import { saveNotify } from "../ops/actions";
export default async function Notifications() {
  await requirePermission("dashboard.view");
  const s = await getSettings();
  const on = (k: string) => s[`notify_${k}`] !== "0";
  const [orders, apps, stock, tickets] = await Promise.all([
    on("order") ? db.order.findMany({ where: { status: "NEW" }, take: 20 }) : [], on("app") ? db.sellerApplication.findMany({ where: { status: "PENDING" }, take: 20 }) : [],
    on("stock") ? db.product.findMany({ where: { isActive: true, stock: { lte: 2 } }, take: 20 }) : [], on("ticket") ? db.supportTicket.findMany({ where: { status: "OPEN" }, take: 20 }) : []]);
  const rows: [string, string][] = [...orders.map((o): [string, string] => [`طلب جديد ${o.number}`, "/owner/orders"]), ...apps.map((a): [string, string] => [`طلب انضمام: ${a.storeName}`, "/owner/applications"]), ...stock.map((p): [string, string] => [`مخزون منخفض: ${p.nameAr} (${p.stock})`, "/owner/products"]), ...tickets.map((t): [string, string] => [`تذكرة دعم: ${t.type}`, "/owner/tickets"])];
  return (<main className="mx-auto max-w-2xl space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">الإشعارات</h1>
    <form action={saveNotify} className="space-y-2 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><b>ما الذي تريد أن يصلك؟</b>
      {([["order", "طلب جديد"], ["app", "طلب انضمام بائع"], ["stock", "مخزون منخفض (2 أو أقل)"], ["ticket", "تذكرة دعم جديدة"]] as const).map(([k, t]) => <label key={k} className="block text-sm"><input type="checkbox" name={k} defaultChecked={on(k)} /> {t}</label>)}
      <button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">حفظ</button></form>
    <h2 className="font-bold">الحالية ({rows.length})</h2>{rows.length ? rows.map(([t, h], i) => <Link key={i} href={h} className="block rounded-2xl bg-white p-3 text-sm ring-1 ring-brand-100">{t}</Link>) : <p className="rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">لا توجد إشعارات.</p>}
    <p className="text-xs">إشعارات الهاتف الفورية تُضاف لاحقًا.</p></main>);
}
