import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import { STATUSES, STATUS_LABEL } from "@/lib/orders";
import { setOrderStatus } from "../ops/actions";
export default async function Orders() {
  await requirePermission("orders.manage");
  const orders = await db.order.findMany({ orderBy: { createdAt: "desc" }, take: 100, include: { items: true, city: true } });
  return (<main className="mx-auto max-w-2xl space-y-3 p-4 md:p-8"><Link href="/owner" className="text-sm underline">← مركز القيادة</Link><h1 className="text-2xl font-bold">الطلبات</h1>
    {orders.length === 0 && <p className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100">لا توجد طلبات بعد.</p>}
    {orders.map((o) => <article key={o.id} className="space-y-2 rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">
      <div className="flex justify-between"><b dir="ltr">{o.number}</b><span>{STATUS_LABEL[o.status]}</span></div>
      <p>{o.customerName} · <span dir="ltr">{o.customerPhone}</span><br />{o.city.nameAr} — {o.address}{o.notes && <><br />ملاحظات: {o.notes}</>}</p>
      <p>{o.items.map((i) => `${i.title} ×${i.qty}`).join("، ")}{o.giftWrap && " · تغليف هدية"}</p>
      <p>الإجمالي <b>{mru(o.totalMru)}</b> (توصيل {mru(o.deliveryFeeMru)}) · دفع عند الاستلام</p>
      <form action={setOrderStatus} className="flex gap-2"><input type="hidden" name="id" value={o.id} /><select name="status" defaultValue={o.status} className="rounded-lg border border-brand-100 px-2 py-1">{STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select><button className="text-sm underline">تحديث الحالة</button></form></article>)}</main>);
}
