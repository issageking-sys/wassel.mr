"use server";
import { randomBytes } from "node:crypto";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { assertPermission, ForbiddenError } from "@/lib/auth";
import { hashPassword } from "@/lib/password";
export type ApproveState = { error?: string; creds?: { phone: string; password: string } };
const ip = async () => (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim();

export async function approveApplication(_: ApproveState, fd: FormData): Promise<ApproveState> {
  try {
    const a = await assertPermission("users.manage");
    const id = z.string().parse(fd.get("id"));
    const app = await db.sellerApplication.findUnique({ where: { id } });
    if (!app || app.status !== "PENDING") return { error: "الطلب غير متاح للمراجعة." };
    if (await db.user.findUnique({ where: { phone: app.phone } })) return { error: "الرقم مسجل كمستخدم بالفعل." };
    const role = await db.role.findUniqueOrThrow({ where: { key: "SELLER" } });
    const password = randomBytes(9).toString("base64url");
    const passwordHash = await hashPassword(password);
    const user = await db.$transaction(async (tx) => {
      const u = await tx.user.create({ data: { phone: app.phone, name: app.contactName, cityId: app.cityId, passwordHash, mustChangePassword: true,
        roles: { create: { roleId: role.id } },
        seller: { create: { cityId: app.cityId, status: "VERIFIED", store: { create: { slug: `store-${randomBytes(3).toString("hex")}`, nameAr: app.storeName, description: app.description, cityId: app.cityId, lat: app.lat, lng: app.lng, addressNote: app.addressNote } } } } } });
      await tx.sellerApplication.update({ where: { id }, data: { status: "APPROVED", reviewedById: a.userId, reviewedAt: new Date(), userId: u.id } });
      return u;
    });
    await audit({ actorId: a.userId, action: "seller.application.approve", entityType: "SellerApplication", entityId: id, newValue: { userId: user.id }, ip: await ip() });
    revalidatePath("/owner/applications");
    return { creds: { phone: app.phone, password } };
  } catch (e) { return { error: e instanceof ForbiddenError ? "ليست لديك صلاحية." : "تعذر قبول الطلب." }; }
}

export async function rejectApplication(fd: FormData) {
  const a = await assertPermission("users.manage");
  const p = z.object({ id: z.string(), note: z.string().trim().max(200).optional() }).parse(Object.fromEntries(fd));
  const app = await db.sellerApplication.findUniqueOrThrow({ where: { id: p.id } });
  if (app.status !== "PENDING") return;
  await db.sellerApplication.update({ where: { id: p.id }, data: { status: "REJECTED", reviewNote: p.note || null, reviewedById: a.userId, reviewedAt: new Date() } });
  await audit({ actorId: a.userId, action: "seller.application.reject", entityType: "SellerApplication", entityId: p.id, newValue: { note: p.note ?? null }, ip: await ip() });
  revalidatePath("/owner/applications");
}
