"use client";
import { useActionState } from "react";
import { approveApplication, rejectApplication, type ApproveState } from "./actions";
export default function ReviewActions({ id }: { id: string }) {
  const [s, approve, pending] = useActionState<ApproveState, FormData>(approveApplication, {});
  if (s.creds) return <div className="rounded-lg bg-gold-400/20 p-3 text-sm"><p>تم قبول الطلب وإنشاء الحساب. سلّم البائع هذه البيانات الآن (لن تظهر مرة أخرى):</p><p dir="ltr" className="mt-1 font-mono">{s.creds.phone} / {s.creds.password}</p></div>;
  return (
    <div className="space-y-2">
      <form action={approve}><input type="hidden" name="id" value={id} /><button disabled={pending} className="rounded-lg bg-brand-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">{pending ? "…" : "قبول وإنشاء حساب المتجر"}</button></form>
      {s.error && <p role="alert" className="text-sm text-red-700">{s.error}</p>}
      <form action={rejectApplication} className="flex gap-2"><input type="hidden" name="id" value={id} /><input name="note" placeholder="سبب الرفض (اختياري)" className="flex-1 rounded-lg border border-brand-100 px-2 text-sm" /><button className="text-sm underline">رفض</button></form>
    </div>);
}
