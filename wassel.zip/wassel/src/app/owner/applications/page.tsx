import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import ReviewActions from "./ReviewActions";
const ST = { PENDING: "قيد المراجعة", APPROVED: "مقبول", REJECTED: "مرفوض" } as const;
export default async function Applications() {
  await requirePermission("users.manage");
  const apps = await db.sellerApplication.findMany({ orderBy: [{ status: "asc" }, { createdAt: "desc" }], include: { city: true }, take: 100 });
  return (
    <main className="mx-auto max-w-3xl space-y-4 p-4 md:p-8">
      <Link href="/owner" className="text-sm underline">← مركز القيادة</Link>
      <h1 className="text-2xl font-bold">طلبات الانضمام كبائع</h1>
      {apps.length === 0 && <p className="rounded-2xl bg-white p-8 text-center ring-1 ring-brand-100">لا توجد طلبات بعد.</p>}
      {apps.map((a) => (
        <article key={a.id} className="space-y-2 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
          <div className="flex justify-between"><h2 className="font-bold">{a.storeName}</h2><span className="text-xs">{ST[a.status]}</span></div>
          <p className="text-sm">{a.contactName} · <span dir="ltr">{a.phone}</span> · {a.city.nameAr}</p>
          <p className="text-sm">يبيع: {a.description}</p>
          <p className="text-sm">أقرب معلم: {a.addressNote} {a.lat != null && a.lng != null && <a className="underline" href={`https://www.google.com/maps?q=${a.lat},${a.lng}`} target="_blank" rel="noopener noreferrer">فتح الموقع</a>}</p>
          <p className="text-xs">{a.createdAt.toLocaleString("ar")}{a.reviewNote && ` · ${a.reviewNote}`}</p>
          {a.status === "PENDING" && <ReviewActions id={a.id} />}
        </article>))}
    </main>);
}
