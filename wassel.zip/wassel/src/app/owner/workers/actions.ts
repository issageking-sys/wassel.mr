"use server";
import { randomBytes } from "node:crypto";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { assertPermission, ForbiddenError } from "@/lib/auth";
import { assertCanAssignRole } from "@/lib/owner-guard";
import { hashPassword, normalizePhone } from "@/lib/password";
import { WORKER_ROLES } from "@/lib/workers";

export type CreateState = { error?: string; ok?: { name: string; phone: string; password: string } };
const ip = async () => (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim();

export async function createWorker(_: CreateState, fd: FormData): Promise<CreateState> {
  try {
    const a = await assertPermission("users.manage");
    const p = z.object({ name: z.string().trim().min(2).max(80), phone: z.string(), role: z.enum(WORKER_ROLES), cityId: z.string().min(1), startedAt: z.string().optional(), notes: z.string().max(500).optional() })
      .safeParse(Object.fromEntries(fd));
    const phone = p.success ? normalizePhone(p.data.phone) : null;
    if (!p.success || !phone) return { error: "تحقق من البيانات (الاسم، الهاتف 8 أرقام، الدور، المدينة)." };
    if (p.data.role === "ADMIN" && !a.isOwner) return { error: "إنشاء مدير نظام للمالك فقط." };
    assertCanAssignRole(a, p.data.role);
    if (await db.user.findUnique({ where: { phone } })) return { error: "رقم الهاتف مسجل مسبقًا." };
    const role = await db.role.findUniqueOrThrow({ where: { key: p.data.role } });
    const password = randomBytes(9).toString("base64url");
    const user = await db.user.create({ data: {
      phone, name: p.data.name, cityId: p.data.cityId, passwordHash: await hashPassword(password), mustChangePassword: true,
      roles: { create: { roleId: role.id } },
      employee: { create: { startedAt: p.data.startedAt ? new Date(p.data.startedAt) : undefined, notes: p.data.notes || null } },
      ...(p.data.role === "DELIVERY_AGENT" ? { agent: { create: { cityId: p.data.cityId } } } : {}),
    } });
    await audit({ actorId: a.userId, action: "worker.create", entityType: "User", entityId: user.id, newValue: { name: user.name, role: p.data.role, cityId: p.data.cityId }, ip: await ip() });
    revalidatePath("/owner/workers");
    return { ok: { name: user.name, phone, password } };
  } catch (e) { return { error: e instanceof ForbiddenError ? "ليست لديك صلاحية." : "تعذر إنشاء الحساب." }; }
}

export async function addEntry(fd: FormData) {
  const a = await assertPermission("finance.write");
  const p = z.object({ userId: z.string(), kind: z.enum(["EARNING", "PAYMENT", "EXPENSE"]), amount: z.coerce.number().int().min(1).max(100_000_000), note: z.string().max(200).optional() }).parse(Object.fromEntries(fd));
  if (!(await db.employee.findUnique({ where: { userId: p.userId } }))) throw new ForbiddenError("NOT_A_WORKER");
  const e = await db.workerFinanceEntry.create({ data: { userId: p.userId, kind: p.kind, amountMru: p.amount, note: p.note || null, createdById: a.userId } });
  await audit({ actorId: a.userId, action: "worker.finance.entry", entityType: "WorkerFinanceEntry", entityId: e.id, newValue: { userId: p.userId, kind: p.kind, amountMru: p.amount }, ip: await ip() });
  revalidatePath(`/owner/workers/${p.userId}`);
}

export async function reverseEntry(fd: FormData) {
  const a = await assertPermission("finance.write");
  const p = z.object({ entryId: z.string(), reason: z.string().trim().min(3).max(200) }).parse(Object.fromEntries(fd));
  const o = await db.workerFinanceEntry.findUniqueOrThrow({ where: { id: p.entryId }, include: { reversedBy: true } });
  if (o.isReversal || o.reversedBy) throw new ForbiddenError("ALREADY_REVERSED");
  const r = await db.workerFinanceEntry.create({ data: { userId: o.userId, kind: o.kind, amountMru: o.amountMru, isReversal: true, reversesId: o.id, reason: p.reason, createdById: a.userId } });
  await audit({ actorId: a.userId, action: "worker.finance.reverse", entityType: "WorkerFinanceEntry", entityId: r.id, oldValue: { reverses: o.id }, newValue: { reason: p.reason }, ip: await ip() });
  revalidatePath(`/owner/workers/${o.userId}`);
}

export async function updateNotes(fd: FormData) {
  const a = await assertPermission("users.manage");
  const p = z.object({ userId: z.string(), notes: z.string().max(500) }).parse(Object.fromEntries(fd));
  const old = await db.employee.findUniqueOrThrow({ where: { userId: p.userId } });
  await db.employee.update({ where: { userId: p.userId }, data: { notes: p.notes || null } });
  await audit({ actorId: a.userId, action: "worker.notes.update", entityType: "Employee", entityId: old.id, oldValue: { notes: old.notes }, newValue: { notes: p.notes }, ip: await ip() });
  revalidatePath(`/owner/workers/${p.userId}`);
}
