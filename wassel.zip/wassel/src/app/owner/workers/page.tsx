import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import { ROLE_LABEL, WORKER_ROLES, totals } from "@/lib/workers";
import CreateWorkerForm from "./CreateWorkerForm";

export default async function Workers() {
  await requirePermission("users.manage");
  const [users, cities] = await Promise.all([
    db.user.findMany({ where: { employee: { isNot: null }, roles: { some: { role: { key: { in: [...WORKER_ROLES] } } } } }, orderBy: { createdAt: "desc" },
      include: { city: true, roles: { include: { role: true } }, workerEntries: { select: { kind: true, amountMru: true, isReversal: true } } } }),
    db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }),
  ]);
  const t = users.map((u) => totals(u.workerEntries));
  const S = (k: "earned" | "paid" | "remaining" | "expenses") => t.reduce((a, x) => a + x[k], 0);
  return (
    <main className="mx-auto max-w-5xl space-y-5 p-4 md:p-8">
      <Link href="/owner" className="text-sm underline">← مركز القيادة</Link>
      <h1 className="text-2xl font-bold">العمال</h1>
      <section className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {([["عدد العمال", String(users.length)], ["إجمالي الدخل", mru(S("earned"))], ["المدفوع", mru(S("paid"))], ["المتبقي", mru(S("remaining"))], ["المصاريف", mru(S("expenses"))]] as const).map(([k, v]) =>
          <div key={k} className="rounded-2xl bg-white p-3 ring-1 ring-brand-100"><p className="text-xs">{k}</p><p className="font-bold">{v}</p></div>)}
      </section>
      <div className="grid gap-4 md:grid-cols-[1fr_20rem]">
        <section className="space-y-2">
          {users.length === 0 && <p className="rounded-2xl bg-white p-8 text-center ring-1 ring-brand-100">لا يوجد عمال بعد. أضف أول عامل من النموذج.</p>}
          {users.map((u) => <Link key={u.id} href={`/owner/workers/${u.id}`} className="flex items-center gap-3 rounded-2xl bg-white p-3 ring-1 ring-brand-100 hover:shadow-md">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-brand-700 font-bold text-white">{[...u.name][0]}</span>
            <div className="flex-1"><p className="font-bold">{u.name}</p><p className="text-xs">{u.roles.map((r) => ROLE_LABEL[r.role.key] ?? r.role.nameAr).join("، ")} · {u.city?.nameAr}</p></div>
            <span className="text-xs">{u.status === "ACTIVE" ? "نشط" : "موقوف"}</span></Link>)}
        </section>
        <CreateWorkerForm cities={cities} />
      </div>
    </main>);
}
