import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import { ROLE_LABEL, totals } from "@/lib/workers";
import { addEntry, reverseEntry, updateNotes } from "../actions";
const KIND = { EARNING: "دخل", PAYMENT: "دفعة", EXPENSE: "مصروف" } as const;

export default async function Worker({ params }: { params: Promise<{ id: string }> }) {
  const a = await requirePermission("users.manage");
  const u = await db.user.findFirst({ where: { id: (await params).id, employee: { isNot: null } },
    include: { city: true, employee: true, agent: true, roles: { include: { role: true } }, workerEntries: { orderBy: { createdAt: "desc" }, include: { reversedBy: true } } } });
  if (!u) notFound();
  const t = totals(u.workerEntries);
  const canFin = a.permissions.has("finance.write");
  const i = "rounded-lg border border-brand-100 bg-white px-3 py-2 text-sm";
  return (
    <main className="mx-auto max-w-3xl space-y-5 p-4 md:p-8">
      <Link href="/owner/workers" className="text-sm underline">← كل العمال</Link>
      <header><h1 className="text-2xl font-bold">{u.name}</h1>
        <p className="text-sm">{u.roles.map((r) => ROLE_LABEL[r.role.key] ?? r.role.nameAr).join("، ")} · {u.city?.nameAr} · {u.status === "ACTIVE" ? "نشط" : "موقوف"}{u.agent && ` · ${({ AVAILABLE: "متاح", BUSY: "مشغول", UNAVAILABLE: "غير متاح" })[u.agent.availability]}`}</p></header>
      <dl className="grid grid-cols-2 gap-2 rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">
        <dt>الهاتف</dt><dd dir="ltr" className="font-bold">{u.phone}</dd>
        <dt>بدأ العمل</dt><dd className="font-bold">{u.employee!.startedAt.toLocaleDateString("ar")}</dd>
        <dt>آخر دخول</dt><dd className="font-bold">{u.lastLoginAt ? u.lastLoginAt.toLocaleString("ar") : "لم يدخل بعد"}</dd></dl>
      <section><h2 className="mb-2 font-bold">الحساب المالي</h2>
        <dl className="grid grid-cols-2 gap-2 rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">
          <dt>الدخل</dt><dd className="font-bold">{mru(t.earned)}</dd><dt>المدفوع</dt><dd className="font-bold">{mru(t.paid)}</dd>
          <dt>المتبقي</dt><dd className="font-bold">{mru(t.remaining)}</dd><dt>المصاريف</dt><dd className="font-bold">{mru(t.expenses)}</dd>
          <dt>صافي المستحق</dt><dd className="font-bold">{mru(t.net)}</dd></dl>
        <p className="mt-1 text-xs">صافي المستحق = المتبقي − المصاريف (تعريف مبدئي بانتظار موافقتك). إحصاءات الطلبات والتقييم تظهر بعد بناء الطلبات.</p></section>
      {canFin && <form action={addEntry} className="flex flex-wrap gap-2 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
        <input type="hidden" name="userId" value={u.id} />
        <select name="kind" className={i}>{Object.entries(KIND).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        <input name="amount" type="number" min={1} step={1} placeholder="المبلغ (أوقية)" className={`${i} w-36`} required />
        <input name="note" placeholder="ملاحظة" className={`${i} flex-1`} />
        <button className="rounded-lg bg-brand-700 px-4 font-bold text-white">تسجيل</button></form>}
      <section><h2 className="mb-2 font-bold">السجل المالي (لا يُعدَّل ولا يُحذف)</h2>
        {u.workerEntries.length === 0 ? <p className="rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">لا توجد قيود بعد.</p> :
          <ul className="divide-y divide-brand-100 rounded-2xl bg-white ring-1 ring-brand-100">{u.workerEntries.map((e) => (
            <li key={e.id} className="space-y-1 p-3 text-sm"><div className="flex justify-between"><span>{e.isReversal ? "عكس " : ""}{KIND[e.kind]}{e.note && ` — ${e.note}`}{e.reason && ` — السبب: ${e.reason}`}</span><b>{e.isReversal ? "−" : ""}{mru(e.amountMru)}</b></div>
              <div className="flex justify-between text-xs"><span>{e.createdAt.toLocaleString("ar")}</span>
                {e.reversedBy ? <span>تم عكسه</span> : !e.isReversal && canFin && <form action={reverseEntry} className="flex gap-1"><input type="hidden" name="entryId" value={e.id} /><input name="reason" placeholder="سبب العكس" className="rounded border px-2" required /><button className="underline">عكس</button></form>}</div></li>))}</ul>}</section>
      <form action={updateNotes} className="space-y-2"><h2 className="font-bold">ملاحظات الإدارة</h2><input type="hidden" name="userId" value={u.id} />
        <textarea name="notes" defaultValue={u.employee!.notes ?? ""} rows={3} className={`${i} w-full`} /><button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">حفظ</button></form>
    </main>);
}
