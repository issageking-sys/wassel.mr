"use client";
import { useActionState } from "react";
import { createWorker, type CreateState } from "./actions";
import { ROLE_LABEL, WORKER_ROLES } from "@/lib/workers";
export default function CreateWorkerForm({ cities }: { cities: { id: string; nameAr: string }[] }) {
  const [s, action, pending] = useActionState<CreateState, FormData>(createWorker, {});
  const i = "w-full rounded-lg border border-brand-100 bg-white px-3 py-2 text-sm";
  return (
    <form action={action} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
      <h2 className="font-bold">إضافة عامل</h2>
      <input name="name" placeholder="الاسم الكامل" className={i} required />
      <input name="phone" type="tel" dir="ltr" placeholder="+222 XX XX XX XX" className={`${i} text-start`} required />
      <select name="role" className={i}>{WORKER_ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select>
      <select name="cityId" className={i} required>{cities.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}</select>
      <label className="block text-xs">تاريخ بدء العمل<input name="startedAt" type="date" className={i} /></label>
      <textarea name="notes" placeholder="ملاحظات الإدارة (اختياري)" className={i} rows={2} />
      {s.error && <p role="alert" className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{s.error}</p>}
      {s.ok && <div className="rounded-lg bg-gold-400/20 p-3 text-sm"><p>تم إنشاء حساب <b>{s.ok.name}</b>. سلّمه هذه البيانات الآن، لن تظهر كلمة المرور مرة أخرى:</p><p dir="ltr" className="mt-1 font-mono">{s.ok.phone} / {s.ok.password}</p></div>}
      <button disabled={pending} className="w-full rounded-lg bg-brand-700 py-2 font-bold text-white disabled:opacity-60">{pending ? "جارٍ الإنشاء…" : "إنشاء الحساب"}</button>
    </form>);
}
