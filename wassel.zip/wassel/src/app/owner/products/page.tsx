import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import ImageInput from "@/components/ImageInput";
import { addProduct, setStock, toggleProduct } from "../catalog/actions";
export default async function Products() {
  await requirePermission("catalog.manage");
  const [cats, cities, items] = await Promise.all([db.category.findMany({ where: { parentId: null, isActive: true }, orderBy: { sortOrder: "asc" } }), db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }), db.product.findMany({ orderBy: { createdAt: "desc" }, take: 100, include: { category: true, city: true, store: { include: { city: true } } } })]);
  const i = "w-full rounded-lg border border-brand-100 px-3 py-2 text-sm";
  const ready = cats.length > 0 && cities.length > 0;
  return (<main className="mx-auto max-w-2xl space-y-4 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">إدارة المنتجات</h1>
    {!ready ? <p className="rounded-2xl bg-gold-400/20 p-4 text-sm">أضف قسمًا ومدينة واحدة على الأقل قبل إضافة المنتجات (الإعدادات ثم الأقسام / معلومات الشركة والمدن).</p> :
    <form action={addProduct} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><h2 className="font-bold">منتج جديد</h2>
      <label className="block text-sm">الصورة<ImageInput maxWidth={800} /></label>
      <select name="categoryId" className={i} required>{cats.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}</select>
      <input name="nameAr" placeholder="الاسم / العنوان" className={i} required />
      <input name="brand" placeholder="المؤلف / العلامة التجارية" className={i} />
      <input name="subcategory" placeholder="التصنيف داخل القسم (مثال: تطوير الذات)" className={i} />
      <div className="flex gap-2"><input name="priceMru" type="number" min={1} placeholder="السعر (أوقية)" className={i} required /><input name="stock" type="number" min={0} placeholder="المخزون" className={i} required /></div>
      <select name="cityId" className={i} required>{cities.map((c) => <option key={c.id} value={c.id}>مخزون في {c.nameAr}</option>)}</select>
      <textarea name="description" rows={3} placeholder="الوصف / الملخص" className={i} />
      <button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">إضافة المنتج</button></form>}
    <section className="space-y-2"><h2 className="font-bold">المنتجات ({items.length})</h2>
      {items.map((p) => <div key={p.id} className="space-y-2 rounded-2xl bg-white p-3 ring-1 ring-brand-100"><p><b>{p.nameAr}</b> {!p.isActive && <span className="text-xs">(مخفي)</span>}</p>
        <p className="text-xs">{p.category.nameAr} · {p.city?.nameAr ?? p.store.city.nameAr} · {mru(p.priceMru)} · <span dir="ltr">{p.sku}</span></p>
        <div className="flex flex-wrap items-center gap-2"><form action={setStock} className="flex gap-1"><input type="hidden" name="id" value={p.id} /><input name="stock" type="number" min={0} defaultValue={p.stock} className="w-24 rounded border border-brand-100 px-2 py-1 text-sm" /><button className="text-sm underline">حفظ المخزون</button></form>
          <form action={toggleProduct}><input type="hidden" name="id" value={p.id} /><button className="text-sm underline">{p.isActive ? "إخفاء" : "إظهار"}</button></form></div></div>)}</section></main>);
}
