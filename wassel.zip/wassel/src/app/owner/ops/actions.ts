"use server";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { assertPermission, requireAuth } from "@/lib/auth";
import { setSettings } from "@/lib/site";
import { STATUSES } from "@/lib/orders";
const ip = async () => (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim();

export async function setOrderStatus(fd: FormData) {
  const a = await assertPermission("orders.manage");
  const x = z.object({ id: z.string(), status: z.enum(STATUSES as [string, ...string[]]) }).parse(Object.fromEntries(fd));
  const o = await db.order.findUniqueOrThrow({ where: { id: x.id } });
  if (o.status === x.status) return;
  await db.$transaction([
    db.order.update({ where: { id: o.id }, data: { status: x.status as never } }),
    db.orderStatusLog.create({ data: { orderId: o.id, status: x.status as never, byUserId: a.userId } }),
  ]);
  await audit({ actorId: a.userId, action: "order.status", entityType: "Order", entityId: o.id, oldValue: { status: o.status }, newValue: { status: x.status }, ip: await ip() });
  revalidatePath("/owner/orders");
}
export async function updateTicket(fd: FormData) {
  const a = await assertPermission("support.manage");
  const x = z.object({ id: z.string(), status: z.enum(["OPEN", "IN_PROGRESS", "RESOLVED"]), reply: z.string().trim().max(1000).optional() }).parse(Object.fromEntries(fd));
  await db.supportTicket.update({ where: { id: x.id }, data: { status: x.status, reply: x.reply || null } });
  await audit({ actorId: a.userId, action: "ticket.update", entityType: "SupportTicket", entityId: x.id, newValue: { status: x.status }, ip: await ip() });
  revalidatePath("/owner/tickets");
}
export async function savePage(fd: FormData) {
  const a = await assertPermission("settings.manage");
  const x = z.object({ key: z.enum(["page_about", "page_terms", "page_privacy"]), body: z.string().max(20000) }).parse(Object.fromEntries(fd));
  await setSettings({ [x.key]: x.body });
  await audit({ actorId: a.userId, action: "page.update", entityType: "SiteSetting", entityId: x.key, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function saveNotify(fd: FormData) {
  const a = await assertPermission("dashboard.view");
  await setSettings(Object.fromEntries(["order", "app", "stock", "ticket"].map((k) => [`notify_${k}`, fd.get(k) ? "1" : "0"])));
  await audit({ actorId: a.userId, action: "notify.prefs", entityType: "SiteSetting", ip: await ip() });
  revalidatePath("/owner/notifications");
}
export async function saveProfile(fd: FormData) {
  const a = await requireAuth();
  const x = z.object({ name: z.string().trim().min(2).max(80), email: z.string().trim().email().max(120).or(z.literal("")) }).parse(Object.fromEntries(fd));
  await db.user.update({ where: { id: a.userId }, data: { name: x.name, email: x.email || null } });
  await audit({ actorId: a.userId, action: "profile.update", entityType: "User", entityId: a.userId, newValue: { name: x.name }, ip: await ip() });
  revalidatePath("/owner/profile");
}
