import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { db } from "@/lib/db";
import { TICKET_LABEL } from "@/lib/orders";
import { updateTicket } from "../ops/actions";
export default async function Tickets() {
  await requirePermission("support.manage");
  const list = await db.supportTicket.findMany({ orderBy: { createdAt: "desc" }, take: 100 });
  return (<main className="mx-auto max-w-2xl space-y-3 p-4 md:p-8"><Link href="/owner/settings" className="text-sm underline">← الإعدادات</Link><h1 className="text-2xl font-bold">الدعم الفني</h1>
    {list.length === 0 && <p className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100">لا توجد تذاكر.</p>}
    {list.map((t) => <form key={t.id} action={updateTicket} className="space-y-2 rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100"><input type="hidden" name="id" value={t.id} />
      <div className="flex justify-between"><b>{t.type}</b><span dir="ltr">{t.phone}</span></div><p className="whitespace-pre-wrap">{t.message}</p><p className="text-xs opacity-60">{t.createdAt.toLocaleString("ar")}</p>
      <input name="reply" defaultValue={t.reply ?? ""} placeholder="رد الإدارة" className="w-full rounded-lg border border-brand-100 px-3 py-2" />
      <div className="flex gap-2"><select name="status" defaultValue={t.status} className="rounded-lg border border-brand-100 px-2 py-1">{Object.entries(TICKET_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><button className="underline">حفظ</button></div></form>)}</main>);
}
