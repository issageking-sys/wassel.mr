"use server";
import { randomBytes } from "node:crypto";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { assertPermission } from "@/lib/auth";
import { saveImage } from "@/lib/images";
import { nextSeq, officialStoreId } from "@/lib/catalog";
const ip = async () => (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim();
const opt = z.string().trim().max(200).optional().transform((v) => v || null);

export async function addSection(fd: FormData) {
  const a = await assertPermission("catalog.manage");
  const name = z.string().trim().min(2).max(60).parse(fd.get("name"));
  const imageKey = await saveImage(String(fd.get("image") ?? ""), a.userId);
  const c = await db.category.create({ data: { slug: `s-${randomBytes(4).toString("hex")}`, nameAr: name, imageKey, sortOrder: (await db.category.count({ where: { parentId: null } })) + 1 } });
  await audit({ actorId: a.userId, action: "section.create", entityType: "Category", entityId: c.id, newValue: { name }, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function toggleSection(fd: FormData) {
  const a = await assertPermission("catalog.manage");
  const c = await db.category.findUniqueOrThrow({ where: { id: z.string().parse(fd.get("id")) } });
  await db.category.update({ where: { id: c.id }, data: { isActive: !c.isActive } });
  await audit({ actorId: a.userId, action: "section.toggle", entityType: "Category", entityId: c.id, oldValue: { isActive: c.isActive }, newValue: { isActive: !c.isActive }, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function addProduct(fd: FormData) {
  const a = await assertPermission("catalog.manage");
  const p = z.object({ categoryId: z.string().min(1), nameAr: z.string().trim().min(2).max(120), brand: opt, subcategory: opt, priceMru: z.coerce.number().int().min(1).max(100_000_000), stock: z.coerce.number().int().min(0).max(100000), cityId: z.string().min(1), description: z.string().trim().max(2000).optional().transform((v) => v || null) }).parse(Object.fromEntries(fd));
  const imageKey = await saveImage(String(fd.get("image") ?? ""), a.userId);
  const n = await nextSeq("sku");
  const pr = await db.product.create({ data: { ...p, storeId: await officialStoreId(), slug: `p-${randomBytes(4).toString("hex")}`, sku: `WSL-${String(n).padStart(4, "0")}`, imageKeys: imageKey ? [imageKey] : [] } });
  await audit({ actorId: a.userId, action: "product.create", entityType: "Product", entityId: pr.id, newValue: { nameAr: p.nameAr, priceMru: p.priceMru, stock: p.stock }, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function toggleProduct(fd: FormData) {
  const a = await assertPermission("catalog.manage");
  const p = await db.product.findUniqueOrThrow({ where: { id: z.string().parse(fd.get("id")) } });
  await db.product.update({ where: { id: p.id }, data: { isActive: !p.isActive } });
  await audit({ actorId: a.userId, action: "product.toggle", entityType: "Product", entityId: p.id, oldValue: { isActive: p.isActive }, newValue: { isActive: !p.isActive }, ip: await ip() });
  revalidatePath("/", "layout");
}
export async function setStock(fd: FormData) {
  const a = await assertPermission("catalog.manage");
  const x = z.object({ id: z.string(), stock: z.coerce.number().int().min(0).max(100000) }).parse(Object.fromEntries(fd));
  const p = await db.product.findUniqueOrThrow({ where: { id: x.id } });
  await db.product.update({ where: { id: x.id }, data: { stock: x.stock } });
  await audit({ actorId: a.userId, action: "product.stock", entityType: "Product", entityId: x.id, oldValue: { stock: p.stock }, newValue: { stock: x.stock }, ip: await ip() });
  revalidatePath("/", "layout");
}
