"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { requireAuth } from "@/lib/auth";
import { verifyPassword } from "@/lib/password";
import { encrypt, decrypt, hashCode, newRecoveryCodes, newSecret, verifyTotp } from "@/lib/totp";
export type TotpState = { error?: string; codes?: string[] };

export async function startTotp() {
  const a = await requireAuth();
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  if (u.totpEnabled) return;
  await db.user.update({ where: { id: u.id }, data: { totpSecretEnc: encrypt(newSecret()) } });
  await audit({ actorId: u.id, action: "auth.2fa.start", entityType: "User", entityId: u.id });
  revalidatePath("/security");
}
export async function confirmTotp(_: TotpState, fd: FormData): Promise<TotpState> {
  const a = await requireAuth();
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  const code = String(fd.get("code") ?? "").replace(/\s/g, "");
  if (u.totpEnabled || !u.totpSecretEnc) return { error: "ابدأ الإعداد أولًا." };
  if (!/^\d{6}$/.test(code) || !verifyTotp(decrypt(u.totpSecretEnc), code)) return { error: "الرمز غير صحيح. تأكد من الوقت في هاتفك وحاول مجددًا." };
  const codes = newRecoveryCodes();
  await db.$transaction([
    db.recoveryCode.deleteMany({ where: { userId: u.id } }),
    db.recoveryCode.createMany({ data: codes.map((c) => ({ userId: u.id, codeHash: hashCode(c) })) }),
    db.user.update({ where: { id: u.id }, data: { totpEnabled: true } }),
    db.session.update({ where: { id: a.sessionId }, data: { reauthAt: new Date() } }),
  ]);
  await audit({ actorId: u.id, action: "auth.2fa.enable", entityType: "User", entityId: u.id });
  revalidatePath("/security");
  return { codes };
}
export async function reauth(fd: FormData) {
  const a = await requireAuth();
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  if (!(await verifyPassword(String(fd.get("password") ?? ""), u.passwordHash))) return;
  await db.session.update({ where: { id: a.sessionId }, data: { reauthAt: new Date() } });
  await audit({ actorId: u.id, action: "auth.reauth", entityType: "User", entityId: u.id });
  revalidatePath("/security");
}
