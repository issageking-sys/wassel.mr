"use client";
import { useActionState } from "react";
import { confirmTotp, type TotpState } from "./actions";
export default function TotpConfirm() {
  const [s, action, pending] = useActionState<TotpState, FormData>(confirmTotp, {});
  if (s.codes) return (<div className="rounded-xl bg-gold-400/20 p-4 text-sm"><p className="font-bold">تم تفعيل المصادقة الثنائية.</p>
    <p className="mt-1">احفظ رموز الاسترداد هذه في مكان آمن. كل رمز يعمل مرة واحدة ولن تظهر مرة أخرى:</p>
    <ul dir="ltr" className="mt-2 grid grid-cols-2 gap-1 font-mono">{s.codes.map((c) => <li key={c}>{c}</li>)}</ul></div>);
  return (<form action={action} className="space-y-2"><input name="code" inputMode="numeric" dir="ltr" placeholder="123456" className="w-full rounded-lg border border-brand-100 px-3 py-2" required />
    {s.error && <p role="alert" className="text-sm text-red-700">{s.error}</p>}
    <button disabled={pending} className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white disabled:opacity-60">تأكيد وتفعيل</button></form>);
}
