import Link from "next/link";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";
import { decrypt, otpauthUri } from "@/lib/totp";
import { roleHome } from "@/lib/rbac";
import { reauth, startTotp } from "./actions";
import TotpConfirm from "./TotpConfirm";

export default async function Security() {
  const a = await requireAuth();
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  const secret = !u.totpEnabled && u.totpSecretEnc ? decrypt(u.totpSecretEnc) : null;
  const fresh = Date.now() - a.reauthAt.getTime() < 5 * 60 * 1000;
  const Card = ({ t, children }: { t: string; children: React.ReactNode }) => <section className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><h2 className="font-bold">{t}</h2>{children}</section>;
  return (
    <main className="mx-auto max-w-lg space-y-4 p-4">
      <Link href={roleHome(a.roles)} className="text-sm underline">← رجوع</Link>
      <h1 className="text-2xl font-bold">الأمان</h1>
      <Card t="المصادقة الثنائية (TOTP)">
        {u.totpEnabled ? <p className="text-sm">مفعّلة ✓ — تُطلب عند كل تسجيل دخول.</p> : secret ? (<>
          <ol className="list-decimal space-y-1 ps-5 text-sm"><li>افتح Google Authenticator أو Authy وأضف حسابًا جديدًا.</li><li>اختر "إدخال مفتاح الإعداد" وأدخل هذا المفتاح:</li></ol>
          <p dir="ltr" className="select-all break-all rounded-lg bg-brand-50 p-2 font-mono text-sm">{secret}</p>
          <a className="text-xs underline" href={otpauthUri(secret, u.phone)}>أو افتحه مباشرة في تطبيق المصادقة على هذا الهاتف</a>
          <p className="text-sm">ثم اكتب الرمز المكوّن من 6 أرقام:</p><TotpConfirm /></>) :
          <form action={startTotp}><button className="rounded-lg bg-brand-700 px-4 py-2 font-bold text-white">بدء التفعيل</button></form>}
        {a.isOwner && !u.totpEnabled && <p className="text-xs">مطلوبة لحساب المالك: العمليات الحساسة (مثل إنشاء مالك آخر) تتطلبها.</p>}
      </Card>
      <Card t="إعادة التحقق">
        <p className="text-sm">{fresh ? "تحققت من هويتك قبل قليل ✓ (صالحة 5 دقائق)." : "العمليات الحساسة تتطلب إدخال كلمة المرور مجددًا."}</p>
        <form action={reauth} className="flex gap-2"><input name="password" type="password" dir="ltr" placeholder="كلمة المرور" className="flex-1 rounded-lg border border-brand-100 px-3 py-2" required /><button className="rounded-lg bg-brand-700 px-4 font-bold text-white">تحقق</button></form></Card>
      <Link href="/change-password" className="block text-sm underline">تغيير كلمة المرور</Link>
    </main>);
}
