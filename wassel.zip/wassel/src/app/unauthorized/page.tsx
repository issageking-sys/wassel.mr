import Link from "next/link";
export default function Unauthorized() {
  return (<main className="grid min-h-dvh place-items-center p-6 text-center"><div>
    <h1 className="text-2xl font-bold">لا تملك صلاحية الوصول</h1>
    <Link href="/" className="mt-4 inline-block text-brand-700 underline">العودة</Link></div></main>);
}
