import SectionGrid from "@/components/SectionGrid";
export const metadata = { title: "الأقسام — وصّل" };
export default function Sections() { return <main className="mx-auto max-w-6xl space-y-3 p-3 md:p-6"><h1 className="text-2xl font-bold">الأقسام</h1><SectionGrid /></main>; }
