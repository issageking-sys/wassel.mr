import { getSettings, waLink } from "@/lib/site";
import SupportForm from "./SupportForm";
export const metadata = { title: "الدعم الفني — وصّل" };
export default async function Support() {
  const s = await getSettings();
  return (<main className="mx-auto max-w-xl space-y-3 p-4"><h1 className="text-2xl font-bold">الدعم الفني</h1><p className="text-sm">اكتب مشكلتك وسنتابعها{s.whatsapp ? "، أو تواصل مباشرة عبر واتساب" : ""}.</p>
    <SupportForm />{s.whatsapp && <a href={waLink(s.whatsapp)} className="block text-center text-sm underline">واتساب</a>}</main>);
}
