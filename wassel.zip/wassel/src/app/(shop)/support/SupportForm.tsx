"use client";
import { useActionState } from "react";
import { createTicket, type TicketState } from "./actions";
export default function SupportForm() {
  const [s, action, pending] = useActionState<TicketState, FormData>(createTicket, {});
  const i = "w-full rounded-xl border border-brand-100 bg-white px-3 py-2.5";
  if (s.ok) return <p className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100">تم إرسال طلبك. سنتابعه ونتواصل معك.</p>;
  return (<form action={action} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100"><input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
    <label className="block text-sm">نوع المشكلة<select name="type" className={i}>{["مشكلة في الطلب", "مشكلة في الدفع", "مشكلة في التوصيل", "مشكلة مع البائع", "أخرى"].map((t) => <option key={t}>{t}</option>)}</select></label>
    <label className="block text-sm">رقم هاتفك<input name="phone" type="tel" dir="ltr" className={`${i} text-start`} required /></label>
    <label className="block text-sm">الرسالة<textarea name="message" rows={4} className={i} required /></label>
    {s.error && <p role="alert" className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{s.error}</p>}
    <button disabled={pending} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white disabled:opacity-60">إرسال</button></form>);
}
