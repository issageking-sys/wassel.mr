"use server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { normalizePhone } from "@/lib/password";
export type TicketState = { error?: string; ok?: boolean };
const TYPES = ["مشكلة في الطلب", "مشكلة في الدفع", "مشكلة في التوصيل", "مشكلة مع البائع", "أخرى"];
export async function createTicket(_: TicketState, fd: FormData): Promise<TicketState> {
  if (fd.get("website")) return { ok: true };
  const p = z.object({ type: z.enum(TYPES as [string, ...string[]]), phone: z.string(), message: z.string().trim().min(5).max(1000) }).safeParse(Object.fromEntries(fd));
  const phone = p.success ? normalizePhone(p.data.phone) : null;
  if (!p.success || !phone) return { error: "اكتب رقم هاتفك (8 أرقام) ورسالة واضحة." };
  if ((await db.supportTicket.count({ where: { phone, status: "OPEN" } })) >= 3) return { error: "لديك تذاكر مفتوحة بالفعل. سنتواصل معك." };
  const t = await db.supportTicket.create({ data: { type: p.data.type, phone, message: p.data.message } });
  await audit({ action: "ticket.create", entityType: "SupportTicket", entityId: t.id });
  return { ok: true };
}
