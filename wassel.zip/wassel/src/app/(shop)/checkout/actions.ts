"use server";
import { randomBytes } from "node:crypto";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { loadCart, writeCart } from "@/lib/cart";
import { totalDeliveryFee } from "@/lib/delivery";
import { getSettings, numSetting } from "@/lib/site";
import { normalizePhone } from "@/lib/password";
export type CheckoutState = { error?: string };

export async function placeOrder(_: CheckoutState, fd: FormData): Promise<CheckoutState> {
  if (fd.get("website")) return { error: "تعذر إرسال الطلب." }; // honeypot
  const p = z.object({ name: z.string().trim().min(2).max(80), phone: z.string(), cityId: z.string().min(1), zoneId: z.string().optional(), address: z.string().trim().min(3).max(300), notes: z.string().trim().max(300).optional() }).safeParse(Object.fromEntries(fd));
  const phone = p.success ? normalizePhone(p.data.phone) : null;
  if (!p.success || !phone) return { error: "أكمل الاسم والهاتف (8 أرقام) والمدينة والعنوان." };
  const city = await db.city.findFirst({ where: { id: p.data.cityId, isActive: true } });
  if (!city) return { error: "المدينة غير صحيحة." };
  const zoneId = p.data.zoneId || null;
  if (zoneId && !(await db.zone.findFirst({ where: { id: zoneId, cityId: city.id } }))) return { error: "المنطقة غير صحيحة." };
  const { lines, subtotal } = await loadCart();
  if (!lines.length) return { error: "السلة فارغة أو نفد المخزون." };
  if ((await db.order.count({ where: { customerPhone: phone, status: "NEW" } })) >= 5) return { error: "لديك طلبات جديدة كثيرة قيد المعالجة. تواصل معنا." };
  const site = await getSettings();
  const giftFee = fd.get("gift") ? numSetting(site.gift_fee, 0) : 0;
  const deliveryFee = await totalDeliveryFee(lines.map((l) => l.originCityId), city.id);
  const total = subtotal + deliveryFee + giftFee;
  let token = "";
  try {
    token = randomBytes(12).toString("base64url");
    const order = await db.$transaction(async (tx) => {
      for (const l of lines) { // atomic stock reservation: fails if someone bought it first
        const r = await tx.product.updateMany({ where: { id: l.p.id, isActive: true, stock: { gte: l.q } }, data: { stock: { decrement: l.q } } });
        if (r.count !== 1) throw new Error("STOCK");
      }
      const seq = await tx.sequence.upsert({ where: { key: "order" }, update: { value: { increment: 1 } }, create: { key: "order", value: 1 } });
      return tx.order.create({ data: {
        number: `WAS-${new Date().getFullYear()}-${String(seq.value).padStart(6, "0")}`, token, customerName: p.data.name, customerPhone: phone, cityId: city.id, zoneId, address: p.data.address, notes: p.data.notes || null,
        giftWrap: giftFee > 0, subtotalMru: subtotal, deliveryFeeMru: deliveryFee, giftFeeMru: giftFee, totalMru: total,
        items: { create: lines.map((l) => ({ productId: l.p.id, title: l.p.nameAr, priceMru: l.p.priceMru, qty: l.q, originCityId: l.originCityId })) },
        logs: { create: { status: "NEW" } } } });
    });
    await audit({ action: "order.create", entityType: "Order", entityId: order.id, newValue: { number: order.number, total } });
  } catch (e) {
    return { error: e instanceof Error && e.message === "STOCK" ? "نفد مخزون أحد المنتجات أثناء الطلب. راجع السلة." : "تعذر إنشاء الطلب. حاول مجددًا." };
  }
  await writeCart([]);
  redirect(`/order/${token}`);
}
