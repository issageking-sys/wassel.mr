"use client";
import { useActionState, useState } from "react";
import { placeOrder, type CheckoutState } from "./actions";
type City = { id: string; nameAr: string; zones: { id: string; nameAr: string }[] };
export default function CheckoutForm({ cities, fees, subtotal, giftFee, sameFee, crossFee }: { cities: City[]; fees: Record<string, number>; subtotal: number; giftFee: number; sameFee: number; crossFee: number }) {
  const [s, action, pending] = useActionState<CheckoutState, FormData>(placeOrder, {});
  const [cityId, setCityId] = useState(cities[0]?.id ?? ""), [gift, setGift] = useState(false);
  const zones = cities.find((c) => c.id === cityId)?.zones ?? [];
  const fee = fees[cityId] ?? 0, g = gift ? giftFee : 0, fmt = (n: number) => `${new Intl.NumberFormat("en-US").format(n)} أوقية`;
  const i = "w-full rounded-xl border border-brand-100 bg-white px-3 py-2.5";
  return (
    <form action={action} className="space-y-3">
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <div className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
        <label className="block text-sm">الاسم الكامل<input name="name" className={i} required /></label>
        <label className="block text-sm">رقم الهاتف<input name="phone" type="tel" dir="ltr" placeholder="+222 XX XX XX XX" className={`${i} text-start`} required /></label>
        <label className="block text-sm">المدينة<select name="cityId" value={cityId} onChange={(e) => setCityId(e.target.value)} className={i}>{cities.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}</select></label>
        <label className="block text-sm">الحي أو المنطقة<select name="zoneId" className={i}><option value="">اختر</option>{zones.map((z) => <option key={z.id} value={z.id}>{z.nameAr}</option>)}</select></label>
        <label className="block text-sm">العنوان بالتفصيل<input name="address" className={i} required /></label>
        <label className="block text-sm">ملاحظات التوصيل<input name="notes" className={i} /></label>
        {giftFee > 0 && <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="gift" checked={gift} onChange={(e) => setGift(e.target.checked)} /> تغليف هدية (+{fmt(giftFee)})</label>}
      </div>
      <dl className="grid grid-cols-2 gap-1 rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100"><dt>المجموع الفرعي</dt><dd className="font-bold">{fmt(subtotal)}</dd><dt>التوصيل</dt><dd className="font-bold">{fmt(fee)}</dd>{g > 0 && <><dt>تغليف هدية</dt><dd className="font-bold">{fmt(g)}</dd></>}<dt>الإجمالي</dt><dd className="font-bold">{fmt(subtotal + fee + g)}</dd></dl>
      <p className="rounded-xl bg-gold-400/20 p-3 text-sm">رسوم التوصيل: {fmt(sameFee)} داخل نفس المدينة · {fmt(crossFee)} بين مدينتين. الدفع عند الاستلام نقدًا.</p>
      {s.error && <p role="alert" className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{s.error}</p>}
      <button disabled={pending} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white disabled:opacity-60">{pending ? "جارٍ الإرسال…" : "تأكيد الطلب ←"}</button>
    </form>);
}
