import Link from "next/link";
import { db } from "@/lib/db";
import { loadCart } from "@/lib/cart";
import { totalDeliveryFee } from "@/lib/delivery";
import { getSettings, numSetting } from "@/lib/site";
import CheckoutForm from "./CheckoutForm";
export const metadata = { title: "إتمام الطلب — وصّل" };
export default async function Checkout() {
  const [{ lines, subtotal }, cities, site] = await Promise.all([loadCart(), db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" }, include: { zones: { where: { isActive: true } } } }), getSettings()]);
  if (!lines.length) return <main className="mx-auto max-w-xl p-4"><p className="rounded-2xl bg-white p-6 ring-1 ring-brand-100">السلة فارغة. <Link href="/sections" className="underline">تصفّح الأقسام</Link></p></main>;
  if (!cities.length) return <main className="mx-auto max-w-xl p-4"><p className="rounded-2xl bg-white p-6 ring-1 ring-brand-100">لا توجد مدن مفعّلة بعد.</p></main>;
  const origins = lines.map((l) => l.originCityId);
  const fees = Object.fromEntries(await Promise.all(cities.map(async (c) => [c.id, await totalDeliveryFee(origins, c.id)] as const)));
  return (<main className="mx-auto max-w-xl space-y-3 p-4"><Link href="/cart" className="text-sm underline">← السلة</Link><h1 className="text-2xl font-bold">أين نوصل طلبك؟</h1>
    <CheckoutForm cities={cities.map((c) => ({ id: c.id, nameAr: c.nameAr, zones: c.zones.map((z) => ({ id: z.id, nameAr: z.nameAr })) }))} fees={fees} subtotal={subtotal} giftFee={numSetting(site.gift_fee, 0)} sameFee={numSetting(site.fee_same, 50)} crossFee={numSetting(site.fee_cross, 100)} /></main>);
}
