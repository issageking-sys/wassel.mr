import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import { fileUrl } from "@/lib/images";
import { ProductImage } from "@/components/ProductImage";
import { ProductCard, cardInclude } from "@/components/ProductCard";
import { addToCart } from "../../cart/actions";
const get = (slug: string) => db.product.findFirst({ where: { slug, isActive: true }, include: { category: true, city: true, store: { include: { city: true } } } });

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await get((await params).slug);
  return p ? { title: `${p.nameAr} — وصّل`, description: p.description?.slice(0, 150) } : {};
}
export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await get((await params).slug);
  if (!p) notFound();
  const [similar, fromStore] = await Promise.all([
    db.product.findMany({ where: { categoryId: p.categoryId, id: { not: p.id }, isActive: true }, take: 4, include: cardInclude }),
    db.product.findMany({ where: { storeId: p.storeId, id: { not: p.id }, isActive: true }, take: 4, include: cardInclude }),
  ]);
  const city = p.city?.nameAr ?? p.store.city.nameAr;
  return (
    <main className="mx-auto max-w-5xl space-y-8 p-3 md:p-6">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="overflow-hidden rounded-2xl ring-1 ring-brand-100"><ProductImage label={p.nameAr} src={fileUrl(p.imageKeys[0])} /></div>
        <div className="space-y-3">
          <Link href={`/section/${p.category.slug}`} className="text-sm text-brand-700 underline">{p.category.nameAr}</Link>
          <h1 className="text-2xl font-bold">{p.nameAr}</h1>
          {p.brand && <p className="text-sm opacity-70">{p.brand}{p.subcategory && ` · ${p.subcategory}`}</p>}
          <p className="text-3xl font-bold text-brand-700">{mru(p.priceMru)}</p>
          <p>{p.stock === 0 ? <span className="text-red-600">نفد المخزون</span> : <span className="text-brand-500">متوفر في {city}</span>}</p>
          {p.description && <p className="whitespace-pre-wrap text-sm">{p.description}</p>}
          <form action={addToCart}><input type="hidden" name="productId" value={p.id} />
            <button disabled={p.stock === 0} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white disabled:opacity-40">أضف إلى السلة +</button></form>
        </div>
      </div>
      {[["منتجات مشابهة", similar], ["من نفس المتجر", fromStore]].map(([t, list]) => (list as typeof similar).length > 0 && <section key={t as string}><h2 className="mb-3 text-xl font-bold">{t as string}</h2><div className="grid grid-cols-2 gap-3 md:grid-cols-4">{(list as typeof similar).map((x) => <ProductCard key={x.slug} p={x} />)}</div></section>)}
    </main>);
}
