import Link from "next/link";
import SectionGrid from "@/components/SectionGrid";
export default function Home() {
  return (
    <main className="mx-auto max-w-6xl space-y-8 p-3 md:p-6">
      <section className="rounded-3xl bg-gradient-to-br from-brand-900 to-brand-700 p-8 text-white md:p-14">
        <h1 className="text-3xl font-bold md:text-5xl">من البائع إلى بابك.</h1>
        <p className="mt-3 max-w-lg text-white/80">اشترِ من متاجر مختلفة، ونحن نتولى التوصيل داخل المدينة وبين المدن.</p>
        <div className="mt-6 flex flex-wrap gap-3"><Link href="/sections" className="rounded-xl bg-gold-400 px-6 py-3 font-bold text-brand-900">تصفّح الأقسام</Link>
          <Link href="/become-seller" className="rounded-xl border-2 border-gold-400 px-6 py-3 font-bold">كن بائعًا معنا</Link></div></section>
      <section><h2 className="mb-3 text-xl font-bold">الأقسام</h2><SectionGrid /></section>
    </main>);
}
