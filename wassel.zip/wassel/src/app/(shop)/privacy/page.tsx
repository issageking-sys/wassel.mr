import TextPage from "@/components/TextPage";
export const metadata = { title: "سياسة الخصوصية — وصّل" };
export default function Page() { return <TextPage title="سياسة الخصوصية" keyName="page_privacy" />; }
