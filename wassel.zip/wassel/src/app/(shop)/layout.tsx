import Link from "next/link";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { getAuth } from "@/lib/auth";
import { readCart } from "@/lib/cart";
import { roleHome } from "@/lib/rbac";
import { getSettings, waLink } from "@/lib/site";
import MenuDrawer from "@/components/MenuDrawer";
import { setCity } from "./actions";

export default async function ShopLayout({ children }: { children: React.ReactNode }) {
  const [cities, auth, cur, cart, site] = await Promise.all([db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }), getAuth(), cookies(), readCart(), getSettings()]);
  const sel = cities.find((c) => c.slug === cur.get("wassel_city")?.value);
  const count = cart.reduce((a, l) => a + l.q, 0);
  const links: [string, string][] = [["/", "الرئيسية"], ["/sections", "الأقسام"], ["/cart", `السلة (${count})`], ["/about", "من نحن"], ["/contact", "تواصل معنا"], ["/support", "الدعم الفني"], ["/terms", "الشروط"], ["/privacy", "الخصوصية"], ["/become-seller", "كن بائعًا معنا"], ["/cities-info", "المدن التي نخدمها"], [auth ? roleHome(auth.roles) : "/login", auth ? "حسابي" : "تسجيل الدخول"]];
  return (
    <>
      <header className="sticky top-0 z-30 bg-brand-900 text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 p-3">
          <MenuDrawer links={links} />
          <Link href="/" className="text-2xl font-bold">وصّل <span className="text-xs font-normal text-gold-400">WASSEL</span></Link>
          <form action={setCity} className="flex gap-1 text-xs">
            {cities.map((c) => <button key={c.id} name="city" value={c.slug} className={`rounded-full px-3 py-1 ${sel?.id === c.id ? "bg-gold-400 text-brand-900" : "bg-white/10"}`}>{c.nameAr}</button>)}</form>
          <Link href="/cart" className="ms-auto text-sm">السلة ({count})</Link>
          <form action="/search" className="order-last flex w-full md:order-none md:ms-2 md:w-auto md:flex-1">
            <input name="q" placeholder="ابحث عن منتج أو متجر أو قسم…" className="w-full rounded-s-xl bg-white px-4 py-2 text-brand-900 outline-none" />
            <button className="rounded-e-xl bg-gold-400 px-4 font-bold text-brand-900">بحث</button></form>
        </div>
      </header>
      {children}
      <footer className="mt-12 bg-brand-900 p-8 text-center text-sm text-white/80">
        <p className="font-bold text-white">وصّل — من البائع إلى بابك.</p>
        <p className="mt-1">نخدم: {cities.map((c) => c.nameAr).join(" · ") || "—"}</p>
        {site.whatsapp && <a href={waLink(site.whatsapp)} className="mt-2 inline-block underline">تواصل معنا عبر واتساب</a>}
      </footer>
    </>);
}
