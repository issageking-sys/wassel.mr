import TextPage from "@/components/TextPage";
export const metadata = { title: "من نحن — وصّل" };
export default function Page() { return <TextPage title="من نحن" keyName="page_about" fallback={"وصّل منصة تجارة إلكترونية وتوصيل في موريتانيا. يعرض البائعون منتجاتهم، والزبون يطلب، ونحن نتولى الاستلام والتوصيل إلى بابه.\nنبدأ في نواكشوط ونواذيبو، ونوصّل بين المدينتين، ثم نتوسع إلى بقية المدن."} />; }
