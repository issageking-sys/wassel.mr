import { getSettings, waLink } from "@/lib/site";
export const metadata = { title: "تواصل معنا — وصّل" };
export default async function Contact() {
  const s = await getSettings();
  const none = !s.whatsapp && !s.phone && !s.email;
  return (<main className="mx-auto max-w-xl space-y-3 p-4"><h1 className="text-2xl font-bold">تواصل معنا</h1>
    <div className="space-y-2 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
      {s.whatsapp && <a href={waLink(s.whatsapp)} className="inline-block rounded-xl bg-brand-700 px-5 py-3 font-bold text-white">محادثة واتساب</a>}
      {s.phone && <p>هاتف: <a href={`tel:${s.phone}`} dir="ltr" className="underline">{s.phone}</a></p>}
      {s.email && <p>البريد: <span dir="ltr">{s.email}</span></p>}{none && <p>لم تُضف وسائل التواصل بعد.</p>}</div></main>);
}
