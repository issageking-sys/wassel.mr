import { db } from "@/lib/db";
import { getSettings, waLink } from "@/lib/site";
import ApplyForm from "./ApplyForm";
export const metadata = { title: "كن بائعًا معنا — وصّل" };
export default async function BecomeSeller() {
  const [cities, site] = await Promise.all([db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }), getSettings()]);
  const Box = ({ t, items }: { t: string; items: string[] }) => <section><h2 className="mb-2 font-bold">{t}</h2><ul className="list-disc space-y-1 rounded-2xl bg-white p-4 ps-8 text-sm ring-1 ring-brand-100">{items.map((x) => <li key={x}>{x}</li>)}</ul></section>;
  return (
    <main className="mx-auto max-w-xl space-y-5 p-4">
      <h1 className="text-2xl font-bold">كن بائعًا معنا</h1>
      <p className="rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">لديك متجر أو منتجات؟ اعرضها على وصّل، ونحن نتولى الاستلام والتوصيل إلى زبونك داخل المدينة وبين المدن.</p>
      <Box t="كيف تنضم؟" items={["تقدّم بطلبك من النموذج أدناه.", "تراجع الإدارة بياناتك وتتواصل معك.", "ننشئ لك حساب متجرك.", "تضيف منتجاتك وتبدأ البيع."]} />
      <Box t="ماذا تحصل عليه؟" items={["صفحة متجر خاصة بك داخل وصّل.", "لوحة لإدارة منتجاتك ومخزونك وطلباتك.", "نحن نستلم الطلب منك ونوصله.", "متابعة مبيعاتك ومستحقاتك."]} />
      <h2 className="font-bold">طلب الانضمام</h2>
      <ApplyForm cities={cities} wa={site.whatsapp ? waLink(site.whatsapp) : undefined} />
    </main>);
}
