"use server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { normalizePhone } from "@/lib/password";
export type AppState = { error?: string; ok?: boolean };
const num = (v: FormDataEntryValue | null, lim: number) => { const n = v ? Number(v) : NaN; return Number.isFinite(n) && Math.abs(n) <= lim ? n : undefined; };

export async function submitApplication(_: AppState, fd: FormData): Promise<AppState> {
  if (fd.get("website")) return { ok: true }; // honeypot: bots fill hidden field
  const p = z.object({ storeName: z.string().trim().min(2).max(80), contactName: z.string().trim().min(2).max(80), phone: z.string(), cityId: z.string().min(1), description: z.string().trim().min(5).max(500), addressNote: z.string().trim().min(2).max(200) }).safeParse(Object.fromEntries(fd));
  const phone = p.success ? normalizePhone(p.data.phone) : null;
  if (!p.success || !phone) return { error: "تحقق من البيانات: كل الحقول مطلوبة والهاتف 8 أرقام." };
  if (!(await db.city.findFirst({ where: { id: p.data.cityId, isActive: true } }))) return { error: "المدينة غير صحيحة." };
  if (await db.sellerApplication.findFirst({ where: { phone, status: "PENDING" } })) return { error: "لديك طلب قيد المراجعة بالفعل." };
  if (await db.user.findUnique({ where: { phone } })) return { error: "هذا الرقم مسجل لدينا. سجّل الدخول أو تواصل معنا." };
  const a = await db.sellerApplication.create({ data: { ...p.data, phone, lat: num(fd.get("lat"), 90), lng: num(fd.get("lng"), 180) } });
  await audit({ action: "seller.application.submit", entityType: "SellerApplication", entityId: a.id });
  return { ok: true };
}
