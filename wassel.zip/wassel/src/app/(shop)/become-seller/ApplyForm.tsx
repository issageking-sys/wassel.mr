"use client";
import { useActionState, useState } from "react";
import { submitApplication, type AppState } from "./actions";
export default function ApplyForm({ cities, wa }: { cities: { id: string; nameAr: string }[]; wa?: string }) {
  const [s, action, pending] = useActionState<AppState, FormData>(submitApplication, {});
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [geo, setGeo] = useState("");
  const locate = () => navigator.geolocation.getCurrentPosition((p) => { setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setGeo(""); }, () => setGeo("تعذر تحديد الموقع. يمكنك المتابعة بكتابة أقرب معلم."), { enableHighAccuracy: true, timeout: 10000 });
  const i = "w-full rounded-xl border border-brand-100 bg-white px-3 py-2.5 text-base";
  if (s.ok) return <div className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100"><p className="text-lg font-bold">تم استلام طلبك</p><p className="mt-1 text-sm">ستراجعه الإدارة وتتواصل معك على رقمك.</p>{wa && <a href={wa} className="mt-3 inline-block underline">تواصل معنا عبر واتساب</a>}</div>;
  return (
    <form action={action} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <input type="hidden" name="lat" value={pos?.lat ?? ""} /><input type="hidden" name="lng" value={pos?.lng ?? ""} />
      <label className="block text-sm">اسم المتجر<input name="storeName" className={i} required /></label>
      <label className="block text-sm">اسم المسؤول<input name="contactName" className={i} required /></label>
      <label className="block text-sm">رقم الهاتف<input name="phone" type="tel" dir="ltr" placeholder="+222 XX XX XX XX" className={`${i} text-start`} required /></label>
      <label className="block text-sm">المدينة<select name="cityId" className={i} required>{cities.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}</select></label>
      <label className="block text-sm">ماذا تبيع؟<textarea name="description" rows={2} className={i} required /></label>
      <label className="block text-sm">أقرب معلم لمتجرك<input name="addressNote" className={i} required /></label>
      <div className="text-sm"><button type="button" onClick={locate} className="rounded-xl border border-brand-700 px-3 py-2 font-medium">{pos ? "تم حفظ موقعك ✓ (اضغط للتحديث)" : "شارك موقعي (اختياري)"}</button>{geo && <p className="mt-1 text-red-700">{geo}</p>}</div>
      {s.error && <p role="alert" className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{s.error}</p>}
      <button disabled={pending} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white disabled:opacity-60">{pending ? "جارٍ الإرسال…" : "إرسال الطلب"}</button>
    </form>);
}
