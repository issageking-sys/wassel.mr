import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { fileUrl } from "@/lib/images";
import { ProductImage } from "@/components/ProductImage";
import { ProductCard, cardInclude } from "@/components/ProductCard";
export default async function Section({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ sub?: string }> }) {
  const [{ slug }, { sub }] = await Promise.all([params, searchParams]);
  const c = await db.category.findFirst({ where: { slug, isActive: true } });
  if (!c) notFound();
  const [items, subs] = await Promise.all([
    db.product.findMany({ where: { categoryId: c.id, isActive: true, ...(sub && { subcategory: sub }) }, orderBy: { createdAt: "desc" }, take: 60, include: cardInclude }),
    db.product.findMany({ where: { categoryId: c.id, isActive: true, subcategory: { not: null } }, select: { subcategory: true }, distinct: ["subcategory"] }),
  ]);
  const chip = (on: boolean) => `rounded-full px-3 py-1 text-sm ${on ? "bg-brand-700 text-white" : "bg-white ring-1 ring-brand-100"}`;
  return (
    <main className="mx-auto max-w-6xl space-y-4 p-3 md:p-6">
      <Link href="/sections" className="text-sm underline">← الأقسام</Link>
      <div className="overflow-hidden rounded-2xl"><ProductImage label={c.nameAr} src={fileUrl(c.imageKey)} ratio="aspect-[16/8]" /></div>
      <h1 className="text-2xl font-bold">{c.nameAr}</h1>
      {subs.length > 0 && <div className="flex flex-wrap gap-2"><Link href={`/section/${slug}`} className={chip(!sub)}>الكل</Link>{subs.map((s) => <Link key={s.subcategory} href={`/section/${slug}?sub=${encodeURIComponent(s.subcategory!)}`} className={chip(sub === s.subcategory)}>{s.subcategory}</Link>)}</div>}
      {items.length ? <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{items.map((p) => <ProductCard key={p.slug} p={p} />)}</div> : <p className="rounded-2xl bg-white p-8 text-center ring-1 ring-brand-100">لا توجد منتجات في هذا القسم بعد.</p>}
    </main>);
}
