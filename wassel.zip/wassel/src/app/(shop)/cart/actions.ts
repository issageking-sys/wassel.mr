"use server";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { readCart, writeCart } from "@/lib/cart";
export async function addToCart(fd: FormData) {
  const id = z.string().min(1).parse(fd.get("productId"));
  const p = await db.product.findFirst({ where: { id, isActive: true } });
  if (p && p.stock > 0) {
    const cart = await readCart(), l = cart.find((x) => x.id === id);
    if (l) l.q = Math.min(l.q + 1, p.stock); else cart.push({ id, q: 1 });
    await writeCart(cart);
  }
  redirect("/cart");
}
export async function changeQty(fd: FormData) {
  const id = z.string().parse(fd.get("productId")), d = z.coerce.number().int().min(-1).max(1).parse(fd.get("delta"));
  const cart = await readCart(), l = cart.find((x) => x.id === id);
  if (l) { l.q += d; if (d > 0) { const p = await db.product.findUnique({ where: { id } }); l.q = Math.min(l.q, p?.stock ?? 0); } }
  await writeCart(cart.filter((x) => x.q > 0));
  redirect("/cart");
}
