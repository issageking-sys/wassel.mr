import Link from "next/link";
import { loadCart } from "@/lib/cart";
import { mru } from "@/lib/format";
import { fileUrl } from "@/lib/images";
import { ProductImage } from "@/components/ProductImage";
import { changeQty } from "./actions";
export const metadata = { title: "السلة — وصّل" };
export default async function Cart() {
  const { lines, subtotal } = await loadCart();
  const Btn = ({ id, d, t }: { id: string; d: number; t: string }) => <form action={changeQty} className="inline"><input type="hidden" name="productId" value={id} /><input type="hidden" name="delta" value={d} /><button className="h-8 w-8 rounded-full bg-brand-100 font-bold">{t}</button></form>;
  return (
    <main className="mx-auto max-w-2xl space-y-3 p-4"><h1 className="text-2xl font-bold">السلة</h1>
      {lines.length === 0 ? <p className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100">السلة فارغة. <Link href="/sections" className="underline">تصفّح الأقسام</Link></p> : <>
        {lines.map(({ p, q }) => (
          <div key={p.id} className="flex gap-3 rounded-2xl bg-white p-3 ring-1 ring-brand-100">
            <div className="w-16 shrink-0 overflow-hidden rounded-lg"><ProductImage label={p.nameAr} src={fileUrl(p.imageKeys[0])} /></div>
            <div className="flex-1"><p className="font-medium">{p.nameAr}</p><p className="text-xs opacity-70">{p.brand}</p>
              <div className="mt-2 flex items-center justify-between"><span className="flex items-center gap-2"><Btn id={p.id} d={-1} t="−" /> {q} <Btn id={p.id} d={1} t="+" /></span><b>{mru(p.priceMru * q)}</b></div></div></div>))}
        <div className="rounded-2xl bg-white p-4 ring-1 ring-brand-100"><p className="flex justify-between"><span>المجموع الفرعي</span><b>{mru(subtotal)}</b></p><p className="mt-1 text-sm opacity-70">يُحسب التوصيل حسب مدينتك في الخطوة التالية.</p>
          <Link href="/checkout" className="mt-3 block rounded-xl bg-brand-700 py-3 text-center font-bold text-white">متابعة إلى التوصيل ←</Link></div></>}
    </main>);
}
