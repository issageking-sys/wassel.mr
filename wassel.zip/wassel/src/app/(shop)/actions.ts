"use server";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
export async function setCity(fd: FormData) {
  const slug = String(fd.get("city") ?? "");
  if (await db.city.findFirst({ where: { slug, isActive: true } })) (await cookies()).set("wassel_city", slug, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  revalidatePath("/", "layout");
}
