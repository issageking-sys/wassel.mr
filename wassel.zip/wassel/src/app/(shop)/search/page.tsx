import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ProductCard, cardInclude } from "@/components/ProductCard";
type SP = { q?: string; category?: string; city?: string; min?: string; max?: string; stock?: string; sort?: string; page?: string };
const PAGE = 24;

export default async function Search({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = sp.q?.trim().slice(0, 80);
  const min = Number(sp.min) || undefined, max = Number(sp.max) || undefined;
  const page = Math.max(1, Number(sp.page) || 1);
  const where: Prisma.ProductWhereInput = {
    isActive: true,
    ...(q && { OR: [
      { nameAr: { contains: q, mode: "insensitive" } }, { brand: { contains: q, mode: "insensitive" } }, { subcategory: { contains: q, mode: "insensitive" } },
      { store: { nameAr: { contains: q, mode: "insensitive" } } }, { category: { nameAr: { contains: q, mode: "insensitive" } } },
    ] }),
    ...(sp.category && { category: { slug: sp.category } }),
    ...(sp.city && { OR: [{ city: { slug: sp.city } }, { cityId: null, store: { city: { slug: sp.city } } }] }),
    ...((min || max) && { priceMru: { gte: min, lte: max } }),
    ...(sp.stock && { stock: { gt: 0 } }),
  };
  const orderBy: Prisma.ProductOrderByWithRelationInput = sp.sort === "price_asc" ? { priceMru: "asc" } : sp.sort === "price_desc" ? { priceMru: "desc" } : { createdAt: "desc" };
  const [items, total, cats, cities] = await Promise.all([
    db.product.findMany({ where, orderBy, skip: (page - 1) * PAGE, take: PAGE, include: cardInclude }),
    db.product.count({ where }),
    db.category.findMany({ orderBy: { sortOrder: "asc" } }),
    db.city.findMany({ where: { isActive: true } }),
  ]);
  const link = (p: number) => `/search?${new URLSearchParams({ ...(sp as Record<string, string>), page: String(p) })}`;
  const f = "w-full rounded-lg border border-brand-100 bg-white px-3 py-2 text-sm";
  return (
    <main className="mx-auto grid max-w-6xl gap-4 p-3 md:grid-cols-[14rem_1fr] md:p-6">
      <form className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-brand-100">
        <input name="q" defaultValue={q} placeholder="بحث" className={f} />
        <select name="category" defaultValue={sp.category ?? ""} className={f}><option value="">كل الأقسام</option>{cats.map((c) => <option key={c.id} value={c.slug}>{c.nameAr}</option>)}</select>
        <select name="city" defaultValue={sp.city ?? ""} className={f}><option value="">كل المدن</option>{cities.map((c) => <option key={c.id} value={c.slug}>{c.nameAr}</option>)}</select>
        <div className="flex gap-2"><input name="min" type="number" min={0} defaultValue={min} placeholder="من" className={f} /><input name="max" type="number" min={0} defaultValue={max} placeholder="إلى" className={f} /></div>
        <select name="sort" defaultValue={sp.sort ?? "new"} className={f}><option value="new">الأحدث</option><option value="price_asc">السعر: الأقل</option><option value="price_desc">السعر: الأعلى</option></select>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="stock" value="1" defaultChecked={!!sp.stock} />المتوفر فقط</label>
        <button className="w-full rounded-lg bg-brand-700 py-2 font-bold text-white">تطبيق</button></form>
      <section>
        <p className="mb-3 text-sm">{total} منتج</p>
        {items.length ? <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">{items.map((p) => <ProductCard key={p.slug} p={p} />)}</div> : <p className="rounded-2xl bg-white p-8 text-center ring-1 ring-brand-100">لا توجد نتائج مطابقة.</p>}
        <nav className="mt-6 flex justify-between text-sm">{page > 1 ? <Link href={link(page - 1)}>السابق</Link> : <span />}{page * PAGE < total && <Link href={link(page + 1)}>التالي</Link>}</nav>
      </section>
    </main>);
}
