import TextPage from "@/components/TextPage";
export const metadata = { title: "الشروط والأحكام — وصّل" };
export default function Page() { return <TextPage title="الشروط والأحكام" keyName="page_terms" />; }
