import { db } from "@/lib/db";
export const metadata = { title: "المدن التي نخدمها — وصّل" };
export default async function Cities() {
  const cities = await db.city.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } });
  return (<main className="mx-auto max-w-xl space-y-3 p-4"><h1 className="text-2xl font-bold">المدن التي نخدمها</h1>
    {cities.length ? cities.map((c) => <div key={c.id} className="rounded-2xl bg-white p-4 ring-1 ring-brand-100"><b>{c.nameAr}</b></div>) : <p className="rounded-2xl bg-white p-6 ring-1 ring-brand-100">لم تُضف مدن بعد.</p>}</main>);
}
