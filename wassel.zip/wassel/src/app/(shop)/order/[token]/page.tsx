import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { mru } from "@/lib/format";
import { STATUS_LABEL } from "@/lib/orders";
import { getSettings, waLink } from "@/lib/site";
export const metadata = { title: "طلبك — وصّل", robots: { index: false } };
export default async function OrderPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const [o, site] = await Promise.all([db.order.findUnique({ where: { token }, include: { items: true, city: true, logs: { orderBy: { createdAt: "asc" } } } }), getSettings()]);
  if (!o) notFound();
  return (
    <main className="mx-auto max-w-xl space-y-4 p-4">
      <div className="rounded-2xl bg-white p-6 text-center ring-1 ring-brand-100"><p className="text-4xl text-brand-500">✓</p><h1 className="text-2xl font-bold">تم استلام طلبك</h1>
        <p className="mt-1 text-sm">شكرًا {o.customerName}. سنجهّز طلبك للتوصيل إلى {o.city.nameAr}.</p><p className="mt-2">رقم الطلب <b dir="ltr">{o.number}</b></p>
        <p className="mt-1 text-sm">الحالة: <b>{STATUS_LABEL[o.status]}</b></p>
        {site.whatsapp && <a href={`${waLink(site.whatsapp)}?text=${encodeURIComponent(`رقم طلبي ${o.number}`)}`} className="mt-3 inline-block text-sm underline">تواصل معنا بخصوص الطلب</a>}</div>
      <section className="rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100">{o.items.map((i) => <p key={i.id} className="flex justify-between"><span>{i.title} ×{i.qty}</span><b>{mru(i.priceMru * i.qty)}</b></p>)}
        <hr className="my-2 border-brand-100" /><p className="flex justify-between"><span>التوصيل</span><b>{mru(o.deliveryFeeMru)}</b></p>{o.giftFeeMru > 0 && <p className="flex justify-between"><span>تغليف هدية</span><b>{mru(o.giftFeeMru)}</b></p>}
        <p className="flex justify-between"><span>الإجمالي (الدفع عند الاستلام)</span><b>{mru(o.totalMru)}</b></p></section>
      <section className="rounded-2xl bg-white p-4 text-sm ring-1 ring-brand-100"><h2 className="mb-2 font-bold">تتبّع الطلب</h2><ol className="space-y-1">{o.logs.map((l) => <li key={l.id}>{STATUS_LABEL[l.status]} <span className="text-xs opacity-60">· {l.createdAt.toLocaleString("ar")}</span></li>)}</ol></section>
    </main>);
}
