import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { ProductCard, cardInclude } from "@/components/ProductCard";
export default async function StorePage({ params }: { params: Promise<{ slug: string }> }) {
  const s = await db.store.findFirst({ where: { slug: (await params).slug, isActive: true }, include: { city: true, products: { where: { isActive: true }, include: cardInclude } } });
  if (!s) notFound();
  return (
    <main className="mx-auto max-w-6xl space-y-6 p-3 md:p-6">
      <section className="rounded-3xl bg-gradient-to-br from-brand-900 to-brand-700 p-8 text-white"><h1 className="text-3xl font-bold">{s.nameAr}</h1><p className="mt-1 text-white/80">{s.city.nameAr} · {s.products.length} منتج</p><p className="mt-2 text-sm">{s.description}</p></section>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{s.products.map((p) => <ProductCard key={p.slug} p={p} />)}</div>
    </main>);
}
