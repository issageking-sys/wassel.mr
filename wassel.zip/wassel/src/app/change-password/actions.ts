"use server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { getAuth } from "@/lib/auth";
import { hashPassword, verifyPassword } from "@/lib/password";
import { roleHome } from "@/lib/rbac";
export type PwState = { error?: string };

export async function changePassword(_: PwState, fd: FormData): Promise<PwState> {
  const a = await getAuth();
  if (!a) redirect("/login");
  const cur = String(fd.get("current") ?? ""), next = String(fd.get("next") ?? ""), again = String(fd.get("again") ?? "");
  if (next !== again) return { error: "كلمتا المرور غير متطابقتين." };
  if (next.length < 10 || !/[A-Za-z\u0600-\u06FF]/.test(next) || !/\d/.test(next)) return { error: "كلمة المرور 10 أحرف على الأقل وتحتوي حروفًا وأرقامًا." };
  if (next === cur) return { error: "اختر كلمة مرور مختلفة عن الحالية." };
  const u = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  if (!(await verifyPassword(cur, u.passwordHash))) return { error: "كلمة المرور الحالية غير صحيحة." };
  await db.user.update({ where: { id: u.id }, data: { passwordHash: await hashPassword(next), mustChangePassword: false } });
  await db.session.deleteMany({ where: { userId: u.id, id: { not: a.sessionId } } }); // sign out other devices
  await db.session.update({ where: { id: a.sessionId }, data: { reauthAt: new Date() } });
  await audit({ actorId: u.id, action: "auth.password.change", entityType: "User", entityId: u.id });
  redirect(roleHome(a.roles));
}
