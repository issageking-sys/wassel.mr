"use client";
import { useActionState } from "react";
import { changePassword, type PwState } from "./actions";
export default function PasswordForm() {
  const [s, action, pending] = useActionState<PwState, FormData>(changePassword, {});
  const i = "w-full rounded-xl border border-brand-100 px-3 py-2.5";
  return (<form action={action} className="mt-4 space-y-3">
    <input name="current" type="password" autoComplete="current-password" placeholder="كلمة المرور الحالية" dir="ltr" className={i} required />
    <input name="next" type="password" autoComplete="new-password" placeholder="كلمة المرور الجديدة (10+ أحرف)" dir="ltr" className={i} required />
    <input name="again" type="password" autoComplete="new-password" placeholder="أعد كتابتها" dir="ltr" className={i} required />
    {s.error && <p role="alert" className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{s.error}</p>}
    <button disabled={pending} className="w-full rounded-xl bg-brand-700 py-3 font-bold text-white disabled:opacity-60">{pending ? "…" : "حفظ"}</button></form>);
}
