import { redirect } from "next/navigation";
import { getAuth } from "@/lib/auth";
import PasswordForm from "./PasswordForm";
export default async function Page() {
  const a = await getAuth();
  if (!a) redirect("/login");
  return (<main className="grid min-h-dvh place-items-center p-4"><div className="w-full max-w-sm rounded-2xl bg-white p-6 ring-1 ring-brand-100">
    <h1 className="text-xl font-bold">تغيير كلمة المرور</h1>
    {a.mustChangePassword && <p className="mt-1 text-sm">كلمة مرورك مؤقتة. اختر كلمة مرور خاصة بك للمتابعة.</p>}
    <PasswordForm /></div></main>);
}
