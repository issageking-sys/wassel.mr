import "./globals.css";
import { Tajawal } from "next/font/google";
import type { Metadata } from "next";
const font = Tajawal({ subsets: ["arabic", "latin"], weight: ["400", "500", "700"], variable: "--font-tajawal" });
export const metadata: Metadata = { title: "وصّل — من البائع إلى بابك", description: "منصة تجارة إلكترونية وتوصيل في موريتانيا" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="ar" dir="rtl" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{ __html: "try{var t=localStorage.getItem('wtheme');if(t&&t!=='auto')document.documentElement.setAttribute('data-theme',t)}catch(e){}" }} /></head><body className={`${font.variable} font-sans`}>{children}</body></html>);
}
