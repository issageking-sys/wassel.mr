import { db } from "@/lib/db";
import { getStorage } from "@/storage";
export async function GET(_: Request, { params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  if (!/^img-[a-f0-9]{16}\.(jpg|png|webp)$/.test(key)) return new Response("Not found", { status: 404 });
  const f = await db.storedFile.findUnique({ where: { key } });
  if (!f) return new Response("Not found", { status: 404 });
  const data = await getStorage().get(key);
  return new Response(new Uint8Array(data), { headers: { "Content-Type": f.mime, "Cache-Control": "public, max-age=31536000, immutable" } });
}
