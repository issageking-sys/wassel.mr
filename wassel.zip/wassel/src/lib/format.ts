export const mru = (n: number) => `${new Intl.NumberFormat("en-US").format(n)} أوقية`;
