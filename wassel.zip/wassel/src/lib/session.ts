import { cookies } from "next/headers";
import { createHash, randomBytes } from "node:crypto";
import { db } from "./db";

export const SESSION_COOKIE = "wassel_session";
const TTL_MS = 1000 * 60 * 60 * 24 * 7;
const sha = (t: string) => createHash("sha256").update(t).digest("hex");

export async function createSession(userId: string, meta: { ip?: string; userAgent?: string }) {
  const token = randomBytes(32).toString("base64url");
  await db.session.create({ data: { userId, tokenHash: sha(token), expiresAt: new Date(Date.now() + TTL_MS), ...meta } });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "lax", path: "/", maxAge: TTL_MS / 1000,
  });
}
export async function destroySession() {
  const c = await cookies();
  const t = c.get(SESSION_COOKIE)?.value;
  if (t) await db.session.deleteMany({ where: { tokenHash: sha(t) } });
  c.delete(SESSION_COOKIE);
}
export async function findSession() {
  const t = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!t) return null;
  const s = await db.session.findUnique({
    where: { tokenHash: sha(t) },
    include: { user: { include: { roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } } } } },
  });
  if (!s || s.expiresAt < new Date() || s.user.status !== "ACTIVE") return null;
  return s;
}
