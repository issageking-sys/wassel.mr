import { randomBytes, scrypt as _s, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
const scrypt = promisify(_s) as (p: string, s: Buffer, n: number, o: object) => Promise<Buffer>;
const P = { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 };
export async function hashPassword(pw: string) {
  const salt = randomBytes(16);
  const h = await scrypt(pw, salt, 64, P);
  return `scrypt$${salt.toString("base64")}$${h.toString("base64")}`;
}
export async function verifyPassword(pw: string, stored: string) {
  const [alg, s, h] = stored.split("$");
  if (alg !== "scrypt") return false;
  const calc = await scrypt(pw, Buffer.from(s, "base64"), 64, P);
  const exp = Buffer.from(h, "base64");
  return calc.length === exp.length && timingSafeEqual(calc, exp);
}
// Normalizes Mauritanian numbers to +222XXXXXXXX (8 digits). Returns null if invalid.
export function normalizePhone(raw: string) {
  let d = raw.replace(/[\s\-().+]/g, "").replace(/^00/, "");
  if (d.startsWith("222") && d.length === 11) d = d.slice(3);
  return /^[234]\d{7}$/.test(d) ? `+222${d}` : null;
}
