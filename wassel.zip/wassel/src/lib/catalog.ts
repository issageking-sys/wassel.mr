import { db } from "./db";
// Products need a Store. Items the company sells itself live in one official store tied to the primary owner.
export async function officialStoreId() {
  const co = await db.company.findFirst();
  if (!co) throw new Error("NO_COMPANY");
  const owner = await db.user.findUniqueOrThrow({ where: { id: co.primaryOwnerId } });
  const city = await db.city.findFirst({ where: { isActive: true }, orderBy: { sortOrder: "asc" } });
  const cityId = owner.cityId ?? city?.id;
  if (!cityId) throw new Error("NO_CITY");
  const seller = await db.seller.upsert({ where: { userId: owner.id }, update: {}, create: { userId: owner.id, cityId, status: "VERIFIED" } });
  const store = await db.store.upsert({ where: { sellerId: seller.id }, update: {}, create: { sellerId: seller.id, slug: "wassel", nameAr: "وصّل", cityId: seller.cityId } });
  return store.id;
}
export async function nextSeq(key: string) {
  return (await db.sequence.upsert({ where: { key }, update: { value: { increment: 1 } }, create: { key, value: 1 } })).value;
}
