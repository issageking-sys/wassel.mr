import { db } from "./db";
import type { Prisma } from "@prisma/client";
export function audit(e: { actorId?: string | null; action: string; entityType: string; entityId?: string; oldValue?: Prisma.InputJsonValue; newValue?: Prisma.InputJsonValue; ip?: string }) {
  return db.auditLog.create({ data: { ...e, actorId: e.actorId ?? null } });
}
