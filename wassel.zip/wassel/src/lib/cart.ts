import { cookies } from "next/headers";
import { db } from "./db";
export type CartLine = { id: string; q: number };
const NAME = "wassel_cart";
export async function readCart(): Promise<CartLine[]> {
  try {
    const v = (await cookies()).get(NAME)?.value;
    const a = v ? JSON.parse(v) : [];
    return Array.isArray(a) ? a.filter((x) => typeof x?.id === "string" && Number.isInteger(x?.q) && x.q > 0).slice(0, 30) : [];
  } catch { return []; }
}
export async function writeCart(lines: CartLine[]) {
  (await cookies()).set(NAME, JSON.stringify(lines), { path: "/", maxAge: 60 * 60 * 24 * 14, sameSite: "lax", httpOnly: true });
}
// Prices ALWAYS come from the database, never from the cookie.
export async function loadCart() {
  const raw = await readCart();
  const products = await db.product.findMany({ where: { id: { in: raw.map((l) => l.id) }, isActive: true }, include: { city: true, store: { include: { city: true } } } });
  const lines = raw.flatMap((l) => { const p = products.find((x) => x.id === l.id); const q = p ? Math.min(l.q, p.stock) : 0; return p && q > 0 ? [{ p, q, originCityId: p.cityId ?? p.store.cityId }] : []; });
  return { lines, subtotal: lines.reduce((a, l) => a + l.p.priceMru * l.q, 0), count: lines.reduce((a, l) => a + l.q, 0) };
}
