import { db } from "./db";
import { getSettings, numSetting } from "./site";
// Rule table first (admin-managed matrix, extensible by zone/weight/service); falls back to the two simple settings.
// Defaults 50 / 100 MRU are provisional until the owner confirms them in Settings.
export async function deliveryFee(originCityId: string, destCityId: string) {
  const now = new Date();
  const rule = await db.deliveryFeeRule.findFirst({
    where: { isActive: true, serviceType: "STANDARD", originCityId, destCityId, originZoneId: null, destZoneId: null,
      AND: [{ OR: [{ validFrom: null }, { validFrom: { lte: now } }] }, { OR: [{ validTo: null }, { validTo: { gte: now } }] }] },
    orderBy: { priority: "desc" } });
  if (rule) return rule.feeMru;
  const s = await getSettings();
  return originCityId === destCityId ? numSetting(s.fee_same, 50) : numSetting(s.fee_cross, 100);
}
export async function totalDeliveryFee(originCityIds: string[], destCityId: string) {
  const uniq = [...new Set(originCityIds)];
  return (await Promise.all(uniq.map((o) => deliveryFee(o, destCityId)))).reduce((a, b) => a + b, 0); // one fee per origin city (sub-order)
}
