import { db } from "./db";
export type Site = Record<string, string | undefined>;
export async function getSettings(): Promise<Site> {
  const rows = await db.siteSetting.findMany();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}
export const waLink = (n: string) => `https://wa.me/${n.replace(/\D/g, "")}`;
export const numSetting = (v: string | undefined, d: number) => { const n = Number(v); return v !== undefined && v !== "" && Number.isFinite(n) ? n : d; };
export async function setSettings(entries: Record<string, string>) {
  for (const [key, value] of Object.entries(entries)) await db.siteSetting.upsert({ where: { key }, update: { value }, create: { key, value } });
}
