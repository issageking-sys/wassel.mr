import { db } from "./db";
import { type Auth, ForbiddenError } from "./auth";

const FRESH_MS = 5 * 60 * 1000;
export type UserAction = "update" | "disable" | "delete" | "changeRole" | "changePermissions";

// Sensitive Owner operations need: fresh password re-check AND 2FA enabled.
// FAILS CLOSED: until 2FA enrollment exists (next step), these are denied.
export function assertStrongAuth(actor: Auth) {
  if (!actor.isOwner) throw new ForbiddenError("OWNER_ONLY");
  if (Date.now() - actor.reauthAt.getTime() > FRESH_MS) throw new ForbiddenError("REAUTH_REQUIRED");
  if (!actor.totpEnabled) throw new ForbiddenError("2FA_REQUIRED");
}
export async function assertNotLastOwner(targetUserId: string) {
  const owners = await db.userRole.findMany({ where: { role: { key: "OWNER" }, user: { status: "ACTIVE" } }, select: { userId: true } });
  if (owners.length <= 1 && owners.some((o) => o.userId === targetUserId)) throw new ForbiddenError("LAST_OWNER");
}
export async function assertCanManageUser(actor: Auth, targetUserId: string, action: UserAction) {
  const target = await db.userRole.findFirst({ where: { userId: targetUserId, role: { key: "OWNER" } } });
  if (!target) return; // normal user: caller still checks users.manage
  if (!actor.isOwner) throw new ForbiddenError("OWNER_PROTECTED"); // Admin can't touch an Owner at all
  if (action !== "update") {
    assertStrongAuth(actor);
    if (action === "disable" || action === "delete" || action === "changeRole") await assertNotLastOwner(targetUserId);
  }
}
export function assertCanAssignRole(actor: Auth, roleKey: string) {
  if (roleKey === "OWNER") assertStrongAuth(actor); // creating another Owner
}
export function assertRoleEditable(roleKey: string) {
  if (roleKey === "OWNER") throw new ForbiddenError("OWNER_ROLE_IS_CODE_DEFINED");
}
export function assertCanTransferOwnership(actor: Auth, company: { primaryOwnerId: string }) {
  assertStrongAuth(actor);
  if (company.primaryOwnerId !== actor.userId) throw new ForbiddenError("NOT_PRIMARY_OWNER");
}
