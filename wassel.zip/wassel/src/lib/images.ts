import { randomBytes } from "node:crypto";
import { db } from "./db";
import { getStorage } from "@/storage";
export const fileUrl = (key?: string | null) => (key ? `/api/files/${key}` : undefined);
// Accepts a (client-downscaled) data URL, stores it through the StorageProvider abstraction.
export async function saveImage(dataUrl: string | null | undefined, uploadedById: string) {
  if (!dataUrl) return null;
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) throw new Error("BAD_IMAGE");
  const buf = Buffer.from(m[2], "base64");
  if (buf.length > 600_000) throw new Error("IMAGE_TOO_LARGE");
  const ext = m[1] === "jpeg" ? "jpg" : m[1];
  const key = `img-${randomBytes(8).toString("hex")}.${ext}`;
  await getStorage().put(key, buf, `image/${m[1]}`);
  await db.storedFile.create({ data: { driver: process.env.STORAGE_DRIVER ?? "local", key, mime: `image/${m[1]}`, size: buf.length, uploadedById } });
  return key;
}
