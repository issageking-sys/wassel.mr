import { cache } from "react";
import { redirect } from "next/navigation";
import { findSession } from "./session";
import { type Permission, type RoleKey, OWNER_ONLY, PERMISSIONS } from "./rbac";

export type Auth = {
  userId: string; name: string; phone: string; roles: string[];
  permissions: Set<string>; isOwner: boolean; reauthAt: Date; totpEnabled: boolean;
  mustChangePassword: boolean; sessionId: string;
};
export class ForbiddenError extends Error {}

export const getAuth = cache(async (): Promise<Auth | null> => {
  const s = await findSession();
  if (!s) return null;
  const roles = s.user.roles.map((r) => r.role.key);
  const isOwner = roles.includes("OWNER");
  const perms = new Set<string>(isOwner ? PERMISSIONS : s.user.roles.flatMap((r) => r.role.permissions.map((p) => p.permission.key)));
  if (!isOwner) OWNER_ONLY.forEach((p) => perms.delete(p)); // defense in depth
  return { userId: s.userId, name: s.user.name, phone: s.user.phone, roles, permissions: perms, isOwner, reauthAt: s.reauthAt, totpEnabled: s.user.totpEnabled, mustChangePassword: s.user.mustChangePassword, sessionId: s.id };
});

export async function requireAuth(): Promise<Auth> {
  const a = await getAuth();
  if (!a) redirect("/login");
  if (a.mustChangePassword) redirect("/change-password");
  return a;
}
export async function requirePermission(p: Permission): Promise<Auth> {
  const a = await requireAuth();
  if (!a.permissions.has(p)) redirect("/unauthorized");
  return a;
}
export async function requireRole(...keys: RoleKey[]): Promise<Auth> {
  const a = await requireAuth();
  if (!keys.some((k) => a.roles.includes(k))) redirect("/unauthorized");
  return a;
}
// Use inside Server Actions / route handlers (throw instead of redirect):
export async function assertPermission(p: Permission): Promise<Auth> {
  const a = await getAuth();
  if (!a || a.mustChangePassword || !a.permissions.has(p)) throw new ForbiddenError("FORBIDDEN");
  return a;
}
