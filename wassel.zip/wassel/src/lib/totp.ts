import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function b32(buf: Buffer) { let bits = 0, v = 0, o = ""; for (const b of buf) { v = (v << 8) | b; bits += 8; while (bits >= 5) { o += A[(v >>> (bits - 5)) & 31]; bits -= 5; } v &= (1 << bits) - 1; } if (bits) o += A[(v << (5 - bits)) & 31]; return o; }
function unb32(s: string) { let bits = 0, v = 0; const out: number[] = []; for (const c of s) { const i = A.indexOf(c); if (i < 0) continue; v = (v << 5) | i; bits += 5; if (bits >= 8) { out.push((v >>> (bits - 8)) & 255); bits -= 8; } v &= (1 << bits) - 1; } return Buffer.from(out); }
export const newSecret = () => b32(randomBytes(20));
export function codeAt(secret: string, t = Date.now()) {
  const c = Buffer.alloc(8); c.writeBigUInt64BE(BigInt(Math.floor(t / 30000)));
  const h = createHmac("sha1", unb32(secret)).update(c).digest(); const o = h[19] & 15;
  return String((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000).padStart(6, "0");
}
export function verifyTotp(secret: string, code: string) {
  return [-1, 0, 1].some((w) => { const a = Buffer.from(codeAt(secret, Date.now() + w * 30000)), b = Buffer.from(code); return a.length === b.length && timingSafeEqual(a, b); });
}
export const otpauthUri = (secret: string, account: string) => `otpauth://totp/${encodeURIComponent("WASSEL:" + account)}?secret=${secret}&issuer=WASSEL`;
const key = () => { const k = Buffer.from(process.env.APP_SECRET ?? "", "base64"); if (k.length !== 32) throw new Error("APP_SECRET must be 32 bytes base64"); return k; };
export function encrypt(text: string) { const iv = randomBytes(12), c = createCipheriv("aes-256-gcm", key(), iv); const ct = Buffer.concat([c.update(text, "utf8"), c.final()]); return [iv, c.getAuthTag(), ct].map((b) => b.toString("base64")).join("."); }
export function decrypt(blob: string) { const [iv, tag, ct] = blob.split(".").map((x) => Buffer.from(x, "base64")); const d = createDecipheriv("aes-256-gcm", key(), iv); d.setAuthTag(tag); return Buffer.concat([d.update(ct), d.final()]).toString("utf8"); }
export const hashCode = (c: string) => createHash("sha256").update(c.trim().toLowerCase()).digest("hex");
export const newRecoveryCodes = () => Array.from({ length: 8 }, () => { const h = randomBytes(4).toString("hex"); return `${h.slice(0, 4)}-${h.slice(4)}`; });
