export const WORKER_ROLES = ["ADMIN", "MANAGER", "DELIVERY_MANAGER", "DELIVERY_AGENT"] as const;
export const ROLE_LABEL: Record<string, string> = { ADMIN: "مدير نظام", MANAGER: "مدير", DELIVERY_MANAGER: "مدير توصيل", DELIVERY_AGENT: "مندوب توصيل", OWNER: "المالك" };
type E = { kind: "EARNING" | "PAYMENT" | "EXPENSE"; amountMru: number; isReversal: boolean };
export function totals(entries: E[]) {
  const sum = (k: E["kind"]) => entries.filter((e) => e.kind === k).reduce((a, e) => a + (e.isReversal ? -e.amountMru : e.amountMru), 0);
  const earned = sum("EARNING"), paid = sum("PAYMENT"), expenses = sum("EXPENSE");
  const remaining = earned - paid;
  return { earned, paid, expenses, remaining, net: remaining - expenses }; // net definition pending owner approval
}
