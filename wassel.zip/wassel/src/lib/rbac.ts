// OWNER is NOT stored as DB permissions: it is hard-coded here, so no DB edit
// (or Admin action) can ever reduce or change Owner powers.
export const PERMISSIONS = [
  "dashboard.view", "users.read", "users.manage", "roles.manage",
  "cities.manage", "catalog.manage", "orders.read", "orders.manage",
  "delivery.manage", "finance.read", "finance.write", "expenses.manage",
  "reports.read", "audit.read", "support.manage", "settings.manage",
  "seller.portal", "agent.portal", "customer.portal",
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export const SYSTEM_ROLES = [
  ["OWNER", "المالك"], ["ADMIN", "مدير النظام"], ["MANAGER", "مدير"],
  ["DELIVERY_MANAGER", "مدير التوصيل"], ["SELLER", "بائع"],
  ["DELIVERY_AGENT", "مندوب توصيل"], ["CUSTOMER", "زبون"],
] as const;
export type RoleKey = (typeof SYSTEM_ROLES)[number][0];

export const ROLE_PERMISSIONS: Record<Exclude<RoleKey, "OWNER">, Permission[]> = {
  ADMIN: ["dashboard.view","users.read","users.manage","cities.manage","catalog.manage","orders.read","orders.manage","delivery.manage","finance.read","expenses.manage","reports.read","audit.read","support.manage"],
  MANAGER: ["dashboard.view","users.read","catalog.manage","orders.read","orders.manage","reports.read","support.manage"],
  DELIVERY_MANAGER: ["dashboard.view","orders.read","delivery.manage"],
  SELLER: ["seller.portal"],
  DELIVERY_AGENT: ["agent.portal"],
  CUSTOMER: ["customer.portal"],
};
// Never grantable to anyone but OWNER:
export const OWNER_ONLY: Permission[] = ["roles.manage", "finance.write", "settings.manage"];

export function roleHome(roles: string[]) {
  if (roles.includes("OWNER")) return "/owner";
  if (roles.some((r) => ["ADMIN","MANAGER","DELIVERY_MANAGER"].includes(r))) return "/staff";
  if (roles.includes("SELLER")) return "/seller";
  if (roles.includes("DELIVERY_AGENT")) return "/agent";
  return "/account";
}
