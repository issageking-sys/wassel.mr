export const STATUS_LABEL: Record<string, string> = {
  NEW: "جديد", UNDER_REVIEW: "قيد المراجعة", ACCEPTED: "تم قبول الطلب", PREPARING: "قيد التجهيز", READY_FOR_PICKUP: "جاهز للاستلام",
  AGENT_ASSIGNED: "تم تعيين مندوب", PICKED_UP: "تم الاستلام من البائع", ON_THE_WAY: "في الطريق", ARRIVED_CITY: "وصل إلى المدينة",
  DELIVERED: "تم التسليم", COMPLETED: "مكتمل", CANCELLED: "ملغى", DELIVERY_FAILED: "فشل التسليم", RETURNED: "مرتجع", ISSUE: "مشكلة" };
export const STATUSES = Object.keys(STATUS_LABEL);
export const TICKET_LABEL: Record<string, string> = { OPEN: "مفتوحة", IN_PROGRESS: "قيد المتابعة", RESOLVED: "محلولة" };
