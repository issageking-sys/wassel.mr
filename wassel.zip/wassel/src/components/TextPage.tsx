import { getSettings } from "@/lib/site";
export default async function TextPage({ title, keyName, fallback }: { title: string; keyName: string; fallback?: string }) {
  const s = await getSettings();
  const body = s[keyName] || fallback;
  return (<main className="mx-auto max-w-2xl space-y-3 p-4"><h1 className="text-2xl font-bold">{title}</h1>
    <div className="whitespace-pre-wrap rounded-2xl bg-white p-4 ring-1 ring-brand-100">{body || "لم يُضف هذا النص بعد."}</div></main>);
}
