import Link from "next/link";
import { ProductImage } from "./ProductImage";
import { mru } from "@/lib/format";
import { fileUrl } from "@/lib/images";
export type CardProduct = { slug: string; nameAr: string; brand: string | null; priceMru: number; compareAtMru: number | null; stock: number; imageKeys: string[]; city: { nameAr: string } | null; store: { nameAr: string; city: { nameAr: string } } };
export function ProductCard({ p }: { p: CardProduct }) {
  const off = p.compareAtMru && p.compareAtMru > p.priceMru ? Math.round(100 - (p.priceMru * 100) / p.compareAtMru) : 0;
  return (
    <Link href={`/product/${p.slug}`} className="group block overflow-hidden rounded-2xl bg-white ring-1 ring-brand-100 transition hover:shadow-md">
      <div className="relative overflow-hidden"><ProductImage label={p.nameAr} src={fileUrl(p.imageKeys[0])} className="transition group-hover:scale-[1.03]" />
        {off > 0 && <span className="absolute start-2 top-2 rounded-full bg-gold-400 px-2 py-0.5 text-xs font-bold text-brand-900">-{off}%</span>}
        {p.stock === 0 && <span className="absolute inset-0 grid place-items-center bg-white/70 text-sm font-bold text-brand-900">نفد المخزون</span>}</div>
      <div className="space-y-1 p-3"><p className="line-clamp-2 text-sm font-medium">{p.nameAr}</p>
        <p className="text-xs opacity-70">{[p.brand, p.city?.nameAr ?? p.store.city.nameAr].filter(Boolean).join(" · ")}</p>
        <p className="font-bold text-brand-700">{mru(p.priceMru)}</p></div>
    </Link>);
}
export const cardInclude = { city: { select: { nameAr: true } }, store: { select: { nameAr: true, city: { select: { nameAr: true } } } } } as const;
