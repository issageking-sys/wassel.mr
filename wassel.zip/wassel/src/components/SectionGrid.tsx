import Link from "next/link";
import { db } from "@/lib/db";
import { fileUrl } from "@/lib/images";
import { ProductImage } from "./ProductImage";
export default async function SectionGrid() {
  const list = await db.category.findMany({ where: { parentId: null, isActive: true }, orderBy: { sortOrder: "asc" } });
  if (!list.length) return <p className="rounded-2xl bg-white p-6 text-center text-sm ring-1 ring-brand-100">لا توجد أقسام بعد.</p>;
  return <div className="grid grid-cols-2 gap-3 md:grid-cols-3">{list.map((c) => (
    <Link key={c.id} href={`/section/${c.slug}`} className="overflow-hidden rounded-2xl bg-white ring-1 ring-brand-100 transition hover:shadow-md">
      <ProductImage label={c.nameAr} src={fileUrl(c.imageKey)} ratio="aspect-[16/10]" /><p className="p-3 font-bold">{c.nameAr}</p></Link>))}</div>;
}
