"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
export default function MenuDrawer({ links }: { links: [string, string][] }) {
  const [open, setOpen] = useState(false), [dark, setDark] = useState(false);
  useEffect(() => { const t = document.documentElement.getAttribute("data-theme"); setDark(t === "dark" || (!t && matchMedia("(prefers-color-scheme: dark)").matches)); }, [open]);
  function toggle() { const n = dark ? "light" : "dark"; try { localStorage.setItem("wtheme", n); } catch {} document.documentElement.setAttribute("data-theme", n); setDark(!dark); }
  return (<>
    <button aria-label="القائمة" aria-expanded={open} onClick={() => setOpen(true)} className="grid gap-1.5 p-2"><i className="block h-[3px] w-6 rounded bg-white" /><i className="block h-[3px] w-6 rounded bg-white" /><i className="block h-[3px] w-6 rounded bg-white" /></button>
    {open && <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setOpen(false)} />}
    <nav aria-hidden={!open} className={`fixed inset-y-0 start-0 z-50 w-72 max-w-[80vw] overflow-y-auto bg-white p-4 text-brand-900 shadow-xl transition-transform ${open ? "translate-x-0" : "translate-x-full"}`}>
      {links.map(([h, t]) => <Link key={h + t} href={h} onClick={() => setOpen(false)} className="block border-b border-brand-100 py-3 font-medium">{t}</Link>)}
      <button onClick={toggle} className="mt-2 block w-full py-3 text-start font-medium">الوضع الليلي: {dark ? "مفعّل" : "متوقف"}</button>
    </nav></>);
}
