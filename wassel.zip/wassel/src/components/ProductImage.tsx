// Real image when a key exists; otherwise a neutral branded placeholder.
export function ProductImage({ label, src, className = "", ratio = "aspect-[3/4]" }: { label: string; src?: string; className?: string; ratio?: string }) {
  if (src) return <img src={src} alt={label} loading="lazy" className={`${ratio} w-full object-cover ${className}`} />;
  return <div role="img" aria-label={label} className={`${ratio} grid w-full place-items-center bg-gradient-to-br from-brand-900 to-brand-500 text-5xl font-bold text-white/85 ${className}`}>{[...label][0]}</div>;
}
