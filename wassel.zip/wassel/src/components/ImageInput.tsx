"use client";
import { useState } from "react";
// Downscales in the browser (keeps uploads small) and posts the result as a hidden data-URL field.
export default function ImageInput({ name = "image", maxWidth = 800 }: { name?: string; maxWidth?: number }) {
  const [url, setUrl] = useState("");
  function onFile(f?: File) {
    if (!f) return setUrl("");
    const r = new FileReader();
    r.onload = () => {
      const im = new Image();
      im.onload = () => {
        const w = Math.min(maxWidth, im.width), h = Math.round((im.height * w) / im.width);
        const c = document.createElement("canvas"); c.width = w; c.height = h;
        c.getContext("2d")!.drawImage(im, 0, 0, w, h);
        let q = 0.82, u = c.toDataURL("image/jpeg", q);
        while (u.length > 450_000 && q > 0.4) { q -= 0.1; u = c.toDataURL("image/jpeg", q); }
        setUrl(u);
      };
      im.src = String(r.result);
    };
    r.readAsDataURL(f);
  }
  return (<div className="space-y-2"><input type="file" accept="image/*" onChange={(e) => onFile(e.target.files?.[0])} className="w-full text-sm" />
    <input type="hidden" name={name} value={url} />{url && <img src={url} alt="" className="h-28 rounded-lg object-cover" />}</div>);
}
