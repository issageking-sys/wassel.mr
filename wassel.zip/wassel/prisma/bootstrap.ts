// PRODUCTION bootstrap: roles, permissions, company record and the first OWNER. No demo users, no demo passwords.
// Usage: OWNER_PHONE=+222XXXXXXXX OWNER_NAME="..." OWNER_PASSWORD="12+ chars" npm run db:bootstrap
import { PrismaClient } from "@prisma/client";
import { hashPassword, normalizePhone } from "../src/lib/password";
import { SYSTEM_ROLES, PERMISSIONS, ROLE_PERMISSIONS } from "../src/lib/rbac";
const db = new PrismaClient();

async function main() {
  const ifNeeded = process.argv.includes("--if-needed"); // used by the Netlify build: silently skip when not applicable
  if (ifNeeded && (!process.env.OWNER_PHONE || !process.env.OWNER_PASSWORD)) return console.log("bootstrap: OWNER_* not set, skipping.");
  if (ifNeeded && (await db.company.findFirst())) return console.log("bootstrap: already done, skipping.");
  const phone = normalizePhone(process.env.OWNER_PHONE ?? ""), name = (process.env.OWNER_NAME ?? "").trim(), pw = process.env.OWNER_PASSWORD ?? "";
  if (!phone || name.length < 2 || pw.length < 12) throw new Error("Set OWNER_PHONE (8 digits), OWNER_NAME and OWNER_PASSWORD (12+ chars).");
  if (await db.company.findFirst()) throw new Error("Already bootstrapped (a Company record exists). Refusing to create another owner.");
  for (const key of PERMISSIONS) await db.permission.upsert({ where: { key }, update: {}, create: { key } });
  for (const [key, nameAr] of SYSTEM_ROLES) {
    const role = await db.role.upsert({ where: { key }, update: { nameAr }, create: { key, nameAr, isSystem: true } });
    if (key === "OWNER") continue;
    await db.rolePermission.deleteMany({ where: { roleId: role.id } });
    for (const p of ROLE_PERMISSIONS[key]) {
      const perm = await db.permission.findUniqueOrThrow({ where: { key: p } });
      await db.rolePermission.create({ data: { roleId: role.id, permissionId: perm.id } });
    }
  }
  const owner = await db.role.findUniqueOrThrow({ where: { key: "OWNER" } });
  const user = await db.user.create({ data: { phone, name, passwordHash: await hashPassword(pw), mustChangePassword: true, roles: { create: { roleId: owner.id } } } });
  await db.company.create({ data: { id: "wassel", primaryOwnerId: user.id } });
  console.log(`Owner created: ${phone}. Log in, change the password, then enable 2FA at /security.`);
}
main().finally(() => db.$disconnect());
