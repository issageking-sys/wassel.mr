// DEMO DATA ONLY — safe to delete. Product images are generated placeholders.
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/password";
const db = new PrismaClient();

// No demo catalog: categories, stores and products are added by the Owner/sellers.
const cats: [string, string][] = [];
const stores: { slug: string; name: string; city: string; phone: string; desc: string }[] = [];
const prods: [number, string, string, number, number, number, string][] = [];
async function main() {
  const pw = await hashPassword("Demo#12345");
  const city = (slug: string) => db.city.findUniqueOrThrow({ where: { slug } });
  const sellerRole = await db.role.findUniqueOrThrow({ where: { key: "SELLER" } });
  const zones: Record<string,string[]> = { nouakchott: ["تفرغ زينة","عرفات","الميناء","لكصر"], nouadhibou: ["الشاطئ","المدينة","كانصادو"] };
  for (const [slug, list] of Object.entries(zones)) { const c = await city(slug); for (const nameAr of list) await db.zone.upsert({ where: { cityId_nameAr: { cityId: c.id, nameAr } }, update: {}, create: { cityId: c.id, nameAr } }); }

  for (const [i, [slug, nameAr]] of cats.entries()) await db.category.upsert({ where: { slug }, update: {}, create: { slug, nameAr, sortOrder: i } });

  const storeIds: string[] = [];
  for (const s of stores) {
    const c = await city(s.city);
    const u = await db.user.upsert({ where: { phone: s.phone }, update: {}, create: { phone: s.phone, name: s.name, passwordHash: pw, cityId: c.id } });
    await db.userRole.upsert({ where: { userId_roleId: { userId: u.id, roleId: sellerRole.id } }, update: {}, create: { userId: u.id, roleId: sellerRole.id } });
    const seller = await db.seller.upsert({ where: { userId: u.id }, update: {}, create: { userId: u.id, cityId: c.id, status: "VERIFIED" } });
    const st = await db.store.upsert({ where: { sellerId: seller.id }, update: {}, create: { sellerId: seller.id, slug: s.slug, nameAr: s.name, description: s.desc, cityId: c.id } });
    storeIds.push(st.id);
  }
  for (const [i, [si, cat, nameAr, price, cmp, stock, brand]] of prods.entries()) {
    const category = await db.category.findUniqueOrThrow({ where: { slug: cat } });
    await db.product.upsert({ where: { slug: `${cat}-${i + 1}` }, update: {}, create: {
      slug: `${cat}-${i + 1}`, sku: `WSL-${String(i + 1).padStart(4, "0")}`, storeId: storeIds[si], categoryId: category.id,
      nameAr, brand, priceMru: price, compareAtMru: cmp || null, stock, description: "منتج تجريبي — يمكن حذفه أو استبداله." } });
  }
  if (!(await db.commissionRule.findFirst())) await db.commissionRule.create({ data: { rateBps: 1000, priority: 0 } }); // global default 10%
  for (const [key, value] of [["rounding_mode","NEAREST"],["rounding_remainder_to","PLATFORM"]])
    await db.financialSetting.upsert({ where: { key }, update: {}, create: { key, value } });
  console.log("Catalog seed done.");
}
main().finally(() => db.$disconnect());
