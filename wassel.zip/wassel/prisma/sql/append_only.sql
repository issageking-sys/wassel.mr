CREATE OR REPLACE FUNCTION wassel_forbid_mutation() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION '% on % is forbidden: append-only table', TG_OP, TG_TABLE_NAME; END;
$$ LANGUAGE plpgsql;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['LedgerEntry','LedgerTransaction','AuditLog','WorkerFinanceEntry'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I', t||'_append_only', t);
    EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION wassel_forbid_mutation()', t||'_append_only', t);
  END LOOP;
END $$;

ALTER TABLE "LedgerEntry" DROP CONSTRAINT IF EXISTS ledger_amount_positive;
ALTER TABLE "LedgerEntry" ADD CONSTRAINT ledger_amount_positive CHECK (amount > 0);

ALTER TABLE "WorkerFinanceEntry" DROP CONSTRAINT IF EXISTS worker_entry_amount_positive;
ALTER TABLE "WorkerFinanceEntry" ADD CONSTRAINT worker_entry_amount_positive CHECK ("amountMru" > 0);
