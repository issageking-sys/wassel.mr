// DEMO DATA ONLY — safe to delete. Demo password is public (see README); never use in production.
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/password";
import { SYSTEM_ROLES, PERMISSIONS, ROLE_PERMISSIONS } from "../src/lib/rbac";
const db = new PrismaClient();
const DEMO_PASSWORD = "Demo#12345";

async function main() {
  for (const key of PERMISSIONS) await db.permission.upsert({ where: { key }, update: {}, create: { key } });
  for (const [key, nameAr] of SYSTEM_ROLES) {
    const role = await db.role.upsert({ where: { key }, update: { nameAr }, create: { key, nameAr, isSystem: true } });
    if (key === "OWNER") continue; // Owner powers are code-defined, no DB rows
    await db.rolePermission.deleteMany({ where: { roleId: role.id } });
    for (const p of ROLE_PERMISSIONS[key]) {
      const perm = await db.permission.findUniqueOrThrow({ where: { key: p } });
      await db.rolePermission.create({ data: { roleId: role.id, permissionId: perm.id } });
    }
  }
  const nkc = await db.city.upsert({ where: { slug: "nouakchott" }, update: {}, create: { slug: "nouakchott", nameAr: "نواكشوط", nameFr: "Nouakchott", nameEn: "Nouakchott", isActive: true, sortOrder: 1 } });
  const ndb = await db.city.upsert({ where: { slug: "nouadhibou" }, update: {}, create: { slug: "nouadhibou", nameAr: "نواذيبو", nameFr: "Nouadhibou", nameEn: "Nouadhibou", isActive: true, sortOrder: 2 } });

  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const mk = async (phone: string, name: string, role: string, cityId: string) => {
    const u = await db.user.upsert({ where: { phone }, update: {}, create: { phone, name, passwordHash, cityId } });
    const r = await db.role.findUniqueOrThrow({ where: { key: role } });
    await db.userRole.upsert({ where: { userId_roleId: { userId: u.id, roleId: r.id } }, update: {}, create: { userId: u.id, roleId: r.id } });
    return u;
  };
  const owner = await mk("+22210000001", "المالك (تجريبي)", "OWNER", nkc.id);
  await mk("+22210000002", "مدير النظام (تجريبي)", "ADMIN", nkc.id);
  const s = await mk("+22210000003", "بائع تجريبي", "SELLER", nkc.id);
  const a = await mk("+22210000004", "مندوب تجريبي", "DELIVERY_AGENT", ndb.id);
  const c = await mk("+22210000005", "زبون تجريبي", "CUSTOMER", nkc.id);
  await db.seller.upsert({ where: { userId: s.id }, update: {}, create: { userId: s.id, cityId: nkc.id, status: "VERIFIED" } });
  await db.deliveryAgent.upsert({ where: { userId: a.id }, update: {}, create: { userId: a.id, cityId: ndb.id, availability: "AVAILABLE" } });
  await db.customer.upsert({ where: { userId: c.id }, update: {}, create: { userId: c.id } });
  await db.company.upsert({ where: { id: "wassel" }, update: {}, create: { id: "wassel", primaryOwnerId: owner.id } });
  console.log("Seed done. Demo password:", DEMO_PASSWORD);
}
main().finally(() => db.$disconnect());
