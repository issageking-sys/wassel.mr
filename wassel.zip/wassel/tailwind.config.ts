import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: {
    brand: { 50:"#f1f7f4",100:"#dcebe3",500:"#1f7a54",700:"#14553a",900:"#0b3324" },
    gold: { 400:"#e6b94a", 500:"#d4a031" } },
    fontFamily: { sans: ["var(--font-tajawal)","system-ui","sans-serif"] } } },
} satisfies Config;
